package game;

public enum MarkType {

	X,O,EMPTY
}

