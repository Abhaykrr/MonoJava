package game;


public enum ResultType {

	Progress,Win,Loose,Draw
	
}
