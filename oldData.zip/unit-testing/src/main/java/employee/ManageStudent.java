package employee;

public class ManageStudent {

	public void getStudent(Student student) {
		
	}
}
