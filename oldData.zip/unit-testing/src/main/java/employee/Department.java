package employee;

public class Department {

}
