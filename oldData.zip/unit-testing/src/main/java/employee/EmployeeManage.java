package employee;

public class EmployeeManage {
	
	public static void main(String[] args) {
		System.out.println("he");
		
		Object obj = new Object();
		obj = (Department) obj;
		
		Department dep = new Department();
		
	}
	
	public double empMonthlySalary(Employee emp){

//		Employee emp = new Employee(id,name,basic);
		
		return emp.calculateTotalSalary();
	}
	
	public double empYearlySalary(Employee emp){
		
		return emp.caclulateYearlySalary();
	}
	
	
	
	
	
	

}
