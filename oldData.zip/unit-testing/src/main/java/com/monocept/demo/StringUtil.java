package com.monocept.demo;

import java.util.Arrays;

public class StringUtil {
	
	
	public  String truncateAInFirstTwoPlaces(String str) {
        if (str.length() < 2)
            return str;
        
        String firstTwoChars = str.substring(0, 2);
        String remainingChars = str.substring(2);
        
        if(!firstTwoChars.equals("aa"))return str;
        
        return remainingChars;
    }
    
    public  boolean checkFirstAndLastTwoEqual(String str) {
        if (str.length() < 2)
            return false;
        
        String firstTwoChars = str.substring(0, 2);
        String lastTwoChars = str.substring(str.length() - 2);
        
        return firstTwoChars.equals(lastTwoChars);
    }
    
    public int[] checkArray(int[] arr) {
    	Arrays.sort(arr);
    	
    	return arr;
    }


}

