package com.monocept.demo;

public class Operation {

	public int addition(int a,int b) {
		return a+b;
	}
	
	public int subtraction(int a,int b) {
		return a-b;
	}
	
	public int multiplication(int a,int b) {
		return a*b;
	}
	
	public int division(int a,int b) {
		return a/b;
	}
	
	public boolean IsEven(int a) {
		return a%2==0;
	}
	
	public int[] checkArray() {
		int arr[] =  {1,2,3,4};
		return arr;
	}
	
	public void checkException() {
		throw new NullPointerException();
	}
}
