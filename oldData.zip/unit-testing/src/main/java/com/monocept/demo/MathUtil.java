package com.monocept.demo;

import java.util.Arrays;

public class MathUtil {

	  public int[] checkArray(int[] arr) {
	    	Arrays.sort(arr);
	    	
	    	return arr;
	    }
}
