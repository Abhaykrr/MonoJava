package employee;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class EmployeeManageTest {
	
	EmployeeManage empManage;
	Employee emp;
	
	@BeforeEach
	void init() {
		empManage = new EmployeeManage();
		emp = new Employee(101,"Abhay",20000.0);
	}

	@Test
	void testMain() {
		
	}

	@Test
	void testEmpMonthlySalary() {
		double actual = empManage.empMonthlySalary(emp);
		double expected  = 29000.0;
		
		assertEquals(expected, actual);
	}

	@Test
	void testEmpYearlySalary() {
		
		double actual = empManage.empYearlySalary(emp);
		double expected  = 348000.0;
		
		assertEquals(expected, actual);
	}

}
