package employee;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;

class ManageStudentTest {
	
	@Mock
	Department department;

	@Test
	void testGetStudent() {
//		Department dep = mock(Department.class);
		Student student = new Student(101,"Abhay",department);
	}

}
