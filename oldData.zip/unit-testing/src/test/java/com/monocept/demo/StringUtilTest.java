package com.monocept.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Test;

class StringUtilTest {

StringUtil stringUtil;

@BeforeEach
void init() {
	stringUtil = new StringUtil();
}

@Test
void testTruncateAInFirstTwoPlaces() {
	String testString1 = "strcba";
    
    assertEquals("strcba", stringUtil.truncateAInFirstTwoPlaces(testString1));
  
}

@Test
void testCheckFirstAndLastTwoEqual() {
	 String testString1 = "badsfba";
        
        assertTrue(stringUtil.checkFirstAndLastTwoEqual(testString1));
     
}

@Test
void testCheckArray() {
	int[] actual = {1,2,6,5};
	int expected[] = stringUtil.checkArray(actual);
	
	assertArrayEquals(expected, actual);
}
	



}
