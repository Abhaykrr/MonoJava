package com.monocept.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class OperationTest {

	@Test
	void testAddition() {
		
		Operation operation = new Operation();
		int a =10;
		int b =20;
		int actual = a+b;
		int expected = operation.addition(a, b);
		assertEquals(expected, actual);
		
		
	}
	
	@Test
	void testCheckArray() {		
		Operation operation = new Operation();
		int[] expected  = {1,2,3,4};
		assertArrayEquals(expected, operation.checkArray());
	}
	
	@Test
	void testSubtraction() {
		
		Operation operation = new Operation();
		int a =10;
		int b =20;
		int actual = a-b;
		int expected = operation.subtraction(a, b);
		assertEquals(expected, actual);
		
		
	}

	
	@Test
	void testMultiplication() {
		
		Operation operation = new Operation();
		int a =10;
		int b =20;
		int actual = a*b;
		int expected = operation.multiplication(a, b);
		assertEquals(expected, actual);
		
		
	}

	
	@Test
	void testDivision() {
		
		Operation operation = new Operation();
		int a =10;
		int b =20;
		int actual = a/b;
		int expected = operation.division(a, b);
		assertEquals(expected, actual);
		
		
	}

	
	

}
