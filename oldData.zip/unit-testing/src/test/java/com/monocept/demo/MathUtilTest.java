package com.monocept.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class MathUtilTest {
	
	
	MathUtil mathUtil;
	
	@BeforeEach
	void init() {
		mathUtil = new MathUtil	();
	}

	@Test
	void testCheckArray() {
		int temp [] = {1,3,5,0};
		
		int[] actual = mathUtil.checkArray(temp);
		int expected[] = {1,0,3,5};
		
		assertArrayEquals(expected, actual,"Checking sorted");
	}

}
