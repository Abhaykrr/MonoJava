package streams;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class StreamAssignmnet {
	

	public static void main(String[] args) throws IOException {
		
		List<Country> countrys= setDefaultCountry();
		List<Region> regions = setDefaultRegion();
		
		
		System.out.println("\n____________ACCORDING TO REGION ID_____________________________________________________\n");
		
		for(Region r:regions) {
			
		}
		
		regions.stream().forEach((r)->{
			
		});
		
		for(int i=0;i<regions.size();i++) {
			int context =i;
			System.out.println();
			System.out.println(regions.get(i).getRegionName());
			countrys.stream()
			.filter((obj)->obj.getRegionId()==regions.get(context).getRegionId())
			.forEach(System.out::println);
		}
		
		System.out.println("\n____________ACCORDING TO REGION ID_____________________________________________________\n");
		
			 countrys.stream()
			.sorted((obj1,obj2)->Integer.compare(obj1.getRegionId(), obj2.getRegionId()))
			.forEach(System.out::println);
			 
		 System.out.println("\n____________PARTICULAR REGION ID_____________________________________________________\n");
					 
			 int regionId = 2;
			 
			 countrys.stream()
				.filter((obj)->obj.getRegionId()==regionId)
				.forEach(System.out::println);
			 
			 
		System.out.println("\n_____________COUNT REGIONS_____________________________________________________\n");
		
		for(int i=0;i<regions.size();i++) {
			int context =i;
			System.out.print(regions.get(i).getRegionName()+" has ");
			System.out.print(countrys.stream().filter((obj)->obj.getRegionId()==regions.get(context).getRegionId()).count());
			System.out.println(" Countries");
		}
					 
	
		
	}

	private static List<Country> setDefaultCountry() throws IOException {
		
		List<Country> data = new ArrayList<>();
		
		Files.lines(Paths.get("D:/Monocept/TSM/Country.txt"))
		.forEach((eachLine)->{
			List<String> temp  =new ArrayList<>();
			for(String s:eachLine.split("/"))
				temp.add(s);
			
			data.add(new Country(Integer.parseInt(temp.get(2)),temp.get(0),temp.get(1)));
			
		});

		
		
		
		return data;
	}
	
	private static List<Region> setDefaultRegion() throws IOException {
		
		List<Region> data = new ArrayList<>();
		
		Files.lines(Paths.get("D:/Monocept/TSM/Region.txt"))
		.forEach((eachLine)->{
			List<String> temp  =new ArrayList<>();
			for(String s:eachLine.split("/"))
				temp.add(s);
			
			data.add(new Region(Integer.parseInt(temp.get(0)),temp.get(1)));
			
		});

		
		return data;
	}

}
