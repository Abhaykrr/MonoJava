package streams;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class Test3 {

	public static void main(String[] args) {
		String[] names= {"Jay","Nimesh","Mark","Mahesh","Ramesh"};
		
		Arrays.stream(names).sorted().limit(3).forEach(System.out::println);
		System.out.println();
		
		Arrays.stream(names).filter(name -> name.contains("a")).sorted().limit(3)
        .forEach(System.out::println);
		
		Arrays.stream(names).sorted(Comparator.reverseOrder()).forEach(System.out::println);
		System.out.println();
		
		Arrays.stream(names).forEach((name)->System.out.println(name.substring(0, 3)));
		System.out.println();
		
		Arrays.stream(names).forEach((name)->{if(name.length()<=4) System.out.println(name);});
		
		
		
		List<Integer> numbers=Arrays.asList(16,20,30,40,50,25,35,45); 
		
		System.out.println(numbers.stream().sorted().findFirst());
		numbers.stream().sorted(Comparator.reverseOrder()).limit(1).forEach(System.out::println);
		
		System.out.println(numbers.stream().min(Integer::compareTo));
		System.out.println(numbers.stream().max(Integer::compareTo));
		
	}
	
	
}

