package streams;

import java.util.*;


public class ArrayStreams {

	public static void main(String[] args) {
		String[] names = {"Jayesh", "Nimesh", "Mahesh", "Ramesh"};
		
		Arrays.stream(names).forEach((name)->System.out.print(name +" "));
		System.out.println();
		Arrays.stream(names).forEach(System.out::println);
		System.out.println();
		
		
		
		Arrays.asList(names).forEach((name)->System.out.print(name +" "));
		Arrays.asList(names)args.forEach(System.out::print);
		
		Arrays.stream(names).forEach((name)->printName(name));
		Arrays.stream(names).forEach(ArrayStreams::printName);
		
	}
	
	public static void printName(String name) {
	    System.out.println(name);
	}

}
