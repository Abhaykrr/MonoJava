package streams;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class StreamFiles {

	public static void main(String[] args) throws IOException {
		Files.lines(Paths.get("D:/Monocept/TSM/Demo.txt")).forEach(System.out::println);
	}

}
