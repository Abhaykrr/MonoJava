package streams;

import java.util.Arrays;
import java.util.List;

public class ListOfList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<List<Integer>> lists=Arrays.asList
				(Arrays.asList(1,2,3), Arrays.asList(11,22,33), Arrays.asList(111,222,333));
				System.out.println(lists.stream().
				flatMap(m�>list.stream())
				.reduce(0, (x,y)->x+y));

	}

}
