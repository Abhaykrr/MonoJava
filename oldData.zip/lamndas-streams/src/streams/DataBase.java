package streams;

import java.util.*;

public class DataBase {
	
	static String  temp="";
	
	static List<ArrayList<String>>  getData() {
		List<ArrayList<String>> data = new ArrayList<ArrayList<String>>(Arrays.asList( [{"Abhay","Kumar"},{"Ak","Kumar"}])) ; 
		
		
		
		
		return data;
	}

}
