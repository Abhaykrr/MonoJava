package streams;

import java.util.*;

public class ManageAccount {

	public static void main(String[] args) {
		
		List<Account> accounts = new ArrayList<>(Arrays.asList(new Account(1,"Anil macchi",2000)));
		
		accounts.add(new Account(1,"Abhay",2000));
		accounts.add(new Account(2,"Ak",3000));
		
		accounts.stream().sorted(new CompareBySal()).forEach(System.out::println);
		System.out.println();
		
	     Optional<Account> maxBalanceAccount = accounts.stream()
	                .max((a1, a2) -> Double.compare(a1.getBalance(), a2.getBalance()));
	     
	     System.out.println(maxBalanceAccount);
	     
	     
	     Optional<Account> minBalanceAccount = accounts.stream()
	                .min((a1, a2) -> Double.compare(a1.getBalance(), a2.getBalance()));
	     
	     System.out.println(minBalanceAccount);
	     
	     System.out.println();
	     	
	     accounts.stream().forEach((acc)->{if(acc.getName().length()<=6)System.out.println(acc.getName());});
	     accounts.stream().filter((acc)->acc.getName().length()<=6).forEach(System.out::println);
	 		
//	     int sum=0;	
//	     accounts.stream().forEach((acc)->sum+=acc.getBalance()); 
	     
	     System.out.println(accounts.stream().mapToDouble(Account::getBalance).sum());
	     // can be done by reduce
	
	}
		
}

 class CompareBySal implements Comparator<Account>{

	@Override
	public int compare(Account a1, Account a2) {
		return (int) (a1.getBalance()-a2.getBalance());

}
 }
