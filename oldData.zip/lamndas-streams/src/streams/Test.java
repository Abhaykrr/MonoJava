package streams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Test {

	public static void main(String[] args) {
		
		List<Integer> numbers = new ArrayList<>(Arrays.asList(1,2,3,4));
		
		numbers.stream().forEach((number)->System.out.println(number));

		numbers.stream().forEach((number)->System.out.println(number));
		
		numbers.stream().filter((number)->number%2!=0).forEach((number)->System.out.println(number));
		
		List<Integer> ans = numbers.stream().filter((number)->number%2==0).collect(Collectors.toList());
	
		ans.stream().forEach((num)->System.out.println(num));
		
		System.out.println(numbers.stream().reduce(0,(num1,num2)->num1+num2));
		System.out.println(numbers);
		
		List<String> names = new ArrayList<>(Arrays.asList("Abhay","kumar"));
		
		
	}

}
