package com.tsm.accounts;

public enum AccountType {

	savings,current,joint;

}
