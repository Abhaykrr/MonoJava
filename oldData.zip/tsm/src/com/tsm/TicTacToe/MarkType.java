package com.tsm.TicTacToe;

public enum MarkType {

	X,O,EMPTY
}
