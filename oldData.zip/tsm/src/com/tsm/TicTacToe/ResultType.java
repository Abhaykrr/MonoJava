package com.tsm.TicTacToe;

public enum ResultType {

	Progress,Win,Loose,Draw
	
}
