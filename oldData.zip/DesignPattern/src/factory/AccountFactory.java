package factory;

public class AccountFactory {
	
	private static Account account;
	
	static Account getAccount(String name) {
		
		if(name.equals("savings"))
			account =  new SavingsAccount(101,2000,"Abhay");
		else
			account =  new CurrentAccount(101,2000,"Abhay");
		
		
		return account;
	}

}
