package factory;

public class AccountTest {

	public static void main(String[] args) {
		
		Account a1 = AccountFactory.getAccount("savings");
		Account a2 = AccountFactory.getAccount("current");
		
		System.out.println(a1);
		System.out.println(a2);;
		
		System.out.println(a1==a2);
		

	}

}
