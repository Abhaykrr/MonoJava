package factory;

public class SavingsAccount  extends Account{
	
	private String name;

	public SavingsAccount(int accNo, double balance, String name) {
		super(accNo, balance);
		this.name= name;
		
	}
	
	

	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	@Override
	int getInterest() {
		// TODO Auto-generated method stub
		return 9;
	}



	@Override
	public String toString() {
		return "SavingsAccount [name=" + name + "]";
	}
	
	

}
