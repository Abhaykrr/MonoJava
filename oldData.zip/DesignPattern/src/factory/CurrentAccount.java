package factory;

public class CurrentAccount extends Account {


	private String name;
	
	public CurrentAccount(int accNo, double balance,String name) {
		super(accNo, balance);
		this.name=name;
		
	}
	
	

	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	@Override
	int getInterest() {
		// TODO Auto-generated method stub
		return 8;
	}



	@Override
	public String toString() {
		return "CurrentAccount [name=" + name + "]";
	}
	
	

	
}
