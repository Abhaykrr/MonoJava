package builder;

public class Laptop {
	
	private int ram;
	private int hdd;
	private int cpu;
	
	private boolean wifi;
	private boolean ssd;
	
	public int getRam() {
		return ram;
	}
	public int getHdd() {
		return hdd;
	}
	public int getCpu() {
		return cpu;
	}
	public boolean isWifi() {
		return wifi;
	}
	public boolean isSsd() {
		return ssd;
	}
	
	private Laptop(SimpleLaptopBuilder laptopBuilder) {
		this.ram = laptopBuilder.ram;
		this.cpu = laptopBuilder.cpu;
		this.hdd = laptopBuilder.hdd;
		this.wifi = laptopBuilder.wifi;
		this.ssd = laptopBuilder.ssd;
	}
	
	
	
	
	@Override
	public String toString() {
		return "Laptop [ram=" + ram + ", hdd=" + hdd + ", cpu=" + cpu + ", wifi=" + wifi + ", ssd=" + ssd + "]";
	}




	public static class SimpleLaptopBuilder{
		private int ram;
		private int hdd;
		private int cpu;
		
		private boolean wifi;
		private boolean ssd;
		
		
		public SimpleLaptopBuilder(int ram, int hdd, int cpu) {
			this.ram = ram;
			this.hdd = hdd;
			this.cpu = cpu;
		}


		public  SimpleLaptopBuilder setWifi(boolean wifi) {
			this.wifi = wifi;
			return this;
		}


		public SimpleLaptopBuilder setSsd(boolean ssd) {
			this.ssd = ssd;
			return this;
		}
		
		
		public Laptop build() {
			return new Laptop(this);
		}
		
		
	}
	
	
	public static class GamingLaptopBuilder{
		private int ram;
		private int hdd;
		private int cpu;
		
		private boolean wifi;
		private boolean ssd;
		
		
		public GamingLaptopBuilder(int ram, int hdd) {
			this.ram = ram;
			this.hdd = hdd;
			this.cpu = cpu;
		}


		public  GamingLaptopBuilder setWifi(boolean wifi) {
			this.wifi = wifi;
			return this;
		}


		public GamingLaptopBuilder setSsd(boolean ssd) {
			this.ssd = ssd;
			return this;
		}
		
		
		public Laptop build() {
			return new Laptop(this);
		}
		
		
	}
	
	
}
