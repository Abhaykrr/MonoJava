package builder;


public class LaptopTest {

	public static void main(String[] args) {
		

//		- Used when we have too many arguments to send in Constructor & it's
//		hard to maintain the order.
//
//		� When we don't want to send all parameters in Object initialisation
//		(Generally we send optional parameters as Null)
		
		
//		
//		 We create a 'static nested class', which contains all arguments of
//		outer class.
//
//		� As per naming convention, If class name is 'Vehicle', builder class
//		should be 'VehicleBuilder'
//
//		- Builder class have a public constructor with all required parameters.
//
//		- Builder class should have methods for optional parameters. Method
//		will return the Builder object.
//
//		� A 'build()' method that will return the final Object.
		
//		LaptopBuilder laptopBuilder = new LaptopBuilder();
		
		Laptop simpleLaptop = new Laptop.SimpleLaptopBuilder(8, 256, 8).build();
		
		Laptop gamingLaptop = new Laptop.GamingLaptopBuilder(12, 512).build();
		
		Laptop modified = new Laptop.GamingLaptopBuilder(32, 1024).setSsd(true).setWifi(true).build();
		
		
		System.out.println(mac2);
	}

}
