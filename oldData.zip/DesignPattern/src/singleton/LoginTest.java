package singleton;

public class LoginTest {

	public static void main(String[] args) {
		
		Login l1 = Login.getLogin();
		Login l2 = Login.getLogin();
		
		if(l1==l2) System.out.println("Same");
	}

}
