package singleton;

public class DataBase {
	
	static int count =0;
	
	public DataBase() {
		
	}
	
	public static DataBase getDB() {
		count++;
		if(count==1)
			return new DataBase();
		return null;
	}

}
