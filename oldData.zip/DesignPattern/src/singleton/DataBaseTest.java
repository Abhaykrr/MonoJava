package singleton;

public class DataBaseTest {

	public static void main(String[] args) {
		DataBase db = DataBase.getDB();
		DataBase db2 = DataBase.getDB();
		System.out.println(db);
		
	}

}
