package dataStructure;

public class Linked_List {

	public static void main(String[] args) {
		
		linkedList list = new linkedList();
		
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		list.add(5);
		
		list.delete(1);
		list.display();
		System.out.println();
		
		list.delete(5);
		list.display();
		System.out.println();
		
		list.delete(3);
		list.display();

	}

}

class Node{
	int data;
	Node next;
	
	Node(int data){
		this.data = data ;
		this.next = null;
	}

}

class linkedList{
	
	private Node head;
	
	void add(int data) {
		
		Node temp = head;
		Node newNode = new Node(data);
		
		if(head == null) {
			head = newNode;
			return;
		}
		
		while(temp.next != null) {
			temp = temp.next;
		}
		temp.next = newNode;
	}
	
	
	void display() {
		
		Node temp = head;
		
		while(temp != null) {
			System.out.println(temp.data);
			temp = temp.next;
		}
		
	}
	
	void delete(int data) {
		
		Node temp = head;
		Node prev = null;
		
		while(temp != null) {
			if(temp.data == data) {
				
				if(prev == null) {
					head = temp.next;
				}else {
					prev.next = temp.next;
				}
				return;
			}
			
			prev = temp;
			temp = temp.next;
		}
	}
	
}
