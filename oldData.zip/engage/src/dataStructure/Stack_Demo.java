package dataStructure;

import java.util.*;

public class Stack_Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<List<Integer>> ls = new ArrayList<>();
		
		ls.add(0,Arrays.asList(1,2,3));
		
		System.out.println(ls);

	}

}

class Stack{
	
	
}
