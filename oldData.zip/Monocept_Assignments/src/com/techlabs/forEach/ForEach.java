package com.techlabs.forEach;

public class ForEach {

	public static void main(String[] args) {
		
		for(String string :args)
			System.out.print(string+" ");

	}

}
