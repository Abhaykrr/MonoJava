package com.techlabs.objArray;

public enum AccountType {
	
	savings,current,joint;

}
