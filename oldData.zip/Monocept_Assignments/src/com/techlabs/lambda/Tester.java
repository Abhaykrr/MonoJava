package com.techlabs.lambda;

public interface Tester {
	
	void test();

}
