package com.techlabs.lambda;

public class Test {

	public static void main(String[] args) {
	
		
		Tester tester=()-> System.out.println("Testing Java Skills");
		
		tester.test();
	}

}
