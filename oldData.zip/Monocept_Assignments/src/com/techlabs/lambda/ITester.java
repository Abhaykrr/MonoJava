package com.techlabs.lambda;

public class ITester {

	void test() {
		
	}
}
