package com.techlabs.staticdemo;

public class Demo {

	static {
		System.out.println("Demo static block");
	}
}
