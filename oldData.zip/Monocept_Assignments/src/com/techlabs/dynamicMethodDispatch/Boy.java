package com.techlabs.dynamicMethodDispatch;

public class Boy extends Man{

	
	public void eat() {
		System.out.println("Boy is eating");
	}
	
	public void walk() {
		System.out.println("Boy is walking");
	}
	
	
}
