package com.techlabs.dynamicMethodDispatch;

public class Man {

	public void eat() {
		System.out.println("Man is eating");
	}
	
	public void walk() {
		System.out.println("Man is walking");
	}
	
	public void talk() {
		System.out.println("Man is talking");
	}
}
