package com.techlabs.dynamicMethodDispatch;

public class Kid {

	public void eat() {
		System.out.println("Kid is eating");
	}
	
	
	public void talk() {
		System.out.println("Kid is talking");
	}
}
