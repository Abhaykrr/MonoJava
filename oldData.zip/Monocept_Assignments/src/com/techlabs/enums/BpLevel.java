package com.techlabs.enums;

public enum BpLevel {high,low,normal}
