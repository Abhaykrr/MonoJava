package com.techlabs.debg;

public class BreakPoints {

	public static void main(String[] args) {
		
		int a;
		
		for(int i=0;i<10;i++) {
			a=i+10;
			System.out.println(i);
		}
			
		for(int i=0;i<10;i++) {
			a=i+10;
			System.out.println(i);
		}

	}

}
