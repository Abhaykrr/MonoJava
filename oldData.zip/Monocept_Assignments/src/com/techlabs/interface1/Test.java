package com.techlabs.interface1;


public class Test {

	public static void main(String[] args) {
		
		String str1="ABCDE";
		String str2="ABCDE";
		System.out.println(str1==str2);
	}

}
