package com.techlabs.interface1;

public class Reactangle implements Shape{

	int lenght;
	
	Reactangle(int length){
		
	}
	
	public void area() {
		
	}

}
