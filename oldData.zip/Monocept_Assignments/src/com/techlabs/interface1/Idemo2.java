package com.techlabs.interface1;

public interface Idemo2 {

	default void method() {
		System.out.println("Idemo1");
	}
}
