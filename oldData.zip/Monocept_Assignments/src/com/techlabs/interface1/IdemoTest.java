package com.techlabs.interface1;

public class IdemoTest implements Idemo1,Idemo2 {

	@Override
	public void method() {
		// TODO Auto-generated method stub
		Idemo1.super.method();
	}

}
