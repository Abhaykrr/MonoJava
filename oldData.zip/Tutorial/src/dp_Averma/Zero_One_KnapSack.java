package dp_Averma;

public class Zero_One_KnapSack {

	public static void main(String[] args) {
		int value[]= {20,30,10,50};
		int wt[]= {1,3,4,6};
		int w=10;
		int n=wt.length;
   int ans=ks(wt,value,w,n);
   System.out.println(ans);
	}
	
	
public static int ks(int wt[],int value[],int w,int n) {
	if(n==0||w==0)
		return 0;
	
	if(wt[n-1]<=w)
		return Math.max(value[n-1]+ks(wt,value,w-wt[n-1],n-1),ks(wt,value,w,n-1));
	else 
		return ks(wt,value,w,n-1);
	

}

}
