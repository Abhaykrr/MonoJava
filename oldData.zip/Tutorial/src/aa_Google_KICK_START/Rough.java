package aa_Google_KICK_START;

public class Rough {

	static void add(int a, double b) {
		System.out.println("Hello");
	}
	static void add(double a,int b) {
		System.out.println("By");
	}
	public static void main(String[] args) {
		int a=10;
		double b=10;
		
		
	}

}
