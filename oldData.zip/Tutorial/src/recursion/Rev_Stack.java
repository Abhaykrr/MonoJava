package recursion;

import java.util.Stack;

public class Rev_Stack {
	
	
	static void reverse(Stack<Integer> st) {
		if(st.isEmpty()==true) return ;
		
		int temp=st.pop();	
		
		reverse(st);
		
		insertLast(st,temp);
		
		
	}
	
	static void insertLast(Stack<Integer> st,int elem) {
		
		if(st.isEmpty()==true) { st.push(elem); return ;}
		
		int temp=st.pop();
		
		insertLast(st,elem);
		st.push(temp);
		
	}

	public static void main(String[] args) {
		Stack<Integer> st=new Stack<>();
		st.push(1);
		st.push(2);
		st.push(3);
		st.push(4);
		st.push(5);
		
		
		reverse(st);
		
		while(st.size()!=0) {
			System.out.println(st.pop());
		}
	}

}
