package recursion;

import java.util.Stack;

public class Rev_String {

	
	public static void reverse(Stack<Integer> st) {
		if(st.size()==0) {
			return ;
		}
		
		int temp=st.pop();
		
		reverse(st);
		
		rightPlace(st,temp);
				
		
	}
	
	static void rightPlace(Stack<Integer> st,int elem) {
		
		if(st.size()==0) {
			st.push(elem);
			return;
		}
		int temp=st.pop();
		rightPlace(st,elem);
		st.push(temp);
	}
	
	public static void main(String[] args) {
		Stack<Integer> st=new Stack<>();
		st.push(1);
		st.push(20);
		st.push(3);
		st.push(40);
		st.push(5);
		
		reverse(st);
		System.out.println(st);
	
	}

}
