package recursion;

import java.util.ArrayList;

public class Sort_Array {

	public static void main(String[] args) {
		
	ArrayList<Integer> ll =new ArrayList<>();
	ll.add(5);
	ll.add(4);
	ll.add(3);
	ll.add(2);
	ll.add(1);
	ll.add(0);
	
		sortArr(ll);
		System.out.println(ll);
	}
	
	static void sortArr(ArrayList<Integer> ll) {
		if(ll.size()==1) 	return ;
	
		int temp=ll.get(ll.size()-1);
		ll.remove(ll.size()-1);
		sortArr(ll);
		 	 	
		for(int i=0;i<ll.size();i++) {
			if(temp<ll.get(i)) {
			ll.add(i,temp);
			break;
			}
		}
	}
}
