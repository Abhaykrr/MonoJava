package recursion;

import java.util.Stack;

public class Del_Middle_Stack {

	public static void del(Stack<Integer> st) {
		if(st.size()==3) {
			st.pop();
			return;
		}
		int temp=st.pop();
		
		del(st);
		st.push(temp);
		
		
	}
	public static void main(String[] args) {
		Stack<Integer> st=new Stack<>();
		st.push(1);
		st.push(2);
		st.push(3);
		st.push(4);
		st.push(5);
		
		del(st);
		
		System.out.println(st);

	}

}
