package recursion;

import java.util.Stack;

public class Sort_Stack {
	
	static void sort(Stack<Integer> st) {
		if(st.isEmpty()==true) 
			return;
		
		int temp=st.pop();
		
		sort(st);
		
		correctpos(st,temp);
		
	}
	
	static void correctpos(Stack<Integer> st,int elem) {
		
		if(st.isEmpty()==true||st.peek()<=elem) {
			st.push(elem);
			return;
		}
			
			int temp=st.pop();
			
			correctpos(st,elem);
			
			st.push(temp);
			
		
		
		
	}

	public static void main(String[] args) {
		Stack<Integer> st=new Stack<>();
		st.push(1);
		st.push(20);
		st.push(3);
		st.push(40);
		st.push(5);
		
		sort(st);
		
		while(st.isEmpty()==false) {
			System.out.println(st.pop());
		}
	}

}
