package recursion;

public class Share_chat {

	public static int ans(int length,int n ) {
		int ans=0;
		int arr[]=new int [10];
		arr[0]=126;
		arr[1]=48;  // 0110000
		arr[2]=109;//1101101
		arr[3]=121;//1111001
		arr[4]=51;
		arr[5]=91;
		arr[6]=31;
		arr[7]=112;
		arr[8]=127;
		arr[9]=115;
		
		int no[]=new int[length+1];
		int temp=n;
		
		for(int i=length;i>=1;i--) {
			no[i]=temp%10;
			temp/=10;
		}
		
		int q=0^arr[no[1]];
		while(q>0) {
			if(q%2!=0) {
				ans++;
			}
			q=q>>1;
		}
	
		for(int i=1;i<length;i++) {
			int c=arr[no[i]]^arr[no[i+1]];
			
			while(c>0) {
				if(c%2!=0) 
					ans++;
				c=c>>1;
				
			}
			
		}
	
		
		return ans;
	}
	
	public static void main(String[] args) {
		int a=ans(3,132);
		System.out.println(a);
	}

}
