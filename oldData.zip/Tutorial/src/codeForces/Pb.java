package codeForces;
import java.util.*;
import java.lang.Math;

public class Pb { 
	
	public static void printstepnumbner(int multiplier,int books,int steps) {
		
		int count=0;
		int pos=0;
		
		while(books>0) {
			if(books%multiplier==0) {
				count++;
				books=books/multiplier;
				if(books==1) {
					pos=1;
					break;
				}
					
			}else {
				pos=0;
				break;
			}
		}
		
if(count>steps) {
	System.out.println("Invalid input");

}else {
		if(pos==1) System.out.println(steps-count);
		else System.out.println("Invalid input");
}
		
	}
	
	
	    public static void main(String[] args) {  //   Main   Start
	 
	    	
	    	List<List<Integer>> ll =new ArrayList<List<Integer>>();
	    	
	    	ll.add(Arrays.asList(1,2,3));
	    	ll.add(Arrays.asList(1,2,3));
	    	ll.add(Arrays.asList(1,2,3));
	    	
	    System.out.println(Mul_Arrays(3,ll));
	    	
	    //System.out.println(Mul_Arrays(3,ll));
	  
		   }  // Main Ends
	    
	    public static int Mul_Arrays(int n,List<List<Integer>> A) {
	    
	    	long ans=0;
	    	int anss=0;
	    	int i=0;
	    	
	        for(int l=0;l<n;l++) {
	        	
	    		int arr[]=new int [n];
	    		List<Integer> t=new ArrayList<>();
	    		t=A.get(i);
	    		
	    		for(int j=0;j<n;i++) {
	    			arr[j]=t.get(j);
	    		}
	    	
	    		i++;
	    		
	    	 int[] b=hill(arr,n);
	    		
	    	ArrayList<Integer> temp=new ArrayList<>();
	    	
	    	for(int k=0;k<n;k++) 
	    			temp.add(b[k]);
	    
	    	
	    	while(temp.size()>1) {
	    		for(int k=0;k<temp.size()-1;k++) {
	    			temp.set(k,temp.get(k)*temp.get(k+1) );
	    		}
	    		temp.remove(temp.size()-1);
	    		
	    	}
	    	ans+=temp.get(0);
	    	}
	    	anss=(int) (ans%1000000007);
	    	
	    	return anss;
	    }
	    
	       static  int[] hill(int []arr ,int n) {
	    	   Arrays.sort(arr);
	    	   
	    	 int[] hill=new int[n];
	           int ft=0;
	           int lt=n-1;
	           for(int i=0;i<n;i++)
	           {
	               if(i%2==0)
	                   {
	                       hill[ft]=arr[i];
	                       ft++;
	                   }
	               else
	               {
	                   hill[lt]=arr[i];
	                   lt--;
	               }
	           }
	    	   return hill;
	       }
	           
	           
	           
	           
	           
	           
	           
	           
	           
	           
	           
	    public static int sumoOFsubstring(String num) {
	    	
	    	int res=0;
	    	int n=num.length();
	    	
	    	for(int i=0;i<n;i++) {
	    		for(int j=i+1;j<=n;j++) {
	    			res+=Integer.parseInt(num.substring(i,j));
	    		}
	    	}
	    	
	    	
	    	return res;
	    }
			  } 	// Class Ends
	







//	public static int digits(int n,int k) {
//		int ans=0;
//				while(n>0) {
//					int temp=n%10;
//					if(temp!=k) ans++;
//					n/=10;
//				}
//		return ans;
//	}

/*
	public static int[] assignPrime(int arr[]) {
		for (int i = 2; i < 1000001; i++) {
			if (arr[i] == 1) {
				for (int j = 2 * i; j < 1000001; j += i) {
					arr[j] = 0;
				}
			}
		}
		return arr;
	}

	public static void sortbyColumn(int arr[][], int col) {
		// Using built-in sort function Arrays.sort
		Arrays.sort(arr, new Comparator<int[]>() {

			@Override
			// Compare values according to columns
			public int compare(final int[] entry1, final int[] entry2) {

				// To sort in descending order revert
				// the '>' Operator
				if (entry1[col] > entry2[col])
					return 1;
				else
					return -1;
			}
		}); // End of function call sort().
	}

	static class FastReader {
		BufferedReader br;
		StringTokenizer st;

		public FastReader() {
			br = new BufferedReader(new InputStreamReader(System.in));
		}

		String next() {
			while (st == null || !st.hasMoreElements()) {
				try {
					st = new StringTokenizer(br.readLine());
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			return st.nextToken();
		}

		int nextInt() {
			return Integer.parseInt(next());
		}

		long nextLong() {
			return Long.parseLong(next());
		}

		double nextDouble() {
			return Double.parseDouble(next());
		}

		String nextLine() {
			String str = "";
			try {
				str = br.readLine();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return str;
		}
	}

}
*/
