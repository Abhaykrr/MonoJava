package codeForces;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.*;


public class Pa {
	
	public static int dfs(int arr[][],int x,int y,int n,int m) {
		int ans=0;
		
		if(x<0||x>=n||y<0||y>=m)
			return 0;
		
		if(arr[x][y]==1) {		
			ans+=1;
			arr[x][y]=-1;
		}else {
			return ans;
		}
		
		ans+=dfs(arr,x+1,y,n,m);
		ans+=dfs(arr,x-1,y,n,m);
		ans+=dfs(arr,x,y+1,n,m);
		ans+=dfs(arr,x+1,y-1,n,m);
		
		
		
		
		
		return ans;
	}
	
public static void main(String[] args) {
	
		OutputStream outputStream =System.out;
	    PrintWriter out =new PrintWriter(outputStream);
	    FastReader x =new FastReader();
	    
	
	    int n=x.nextInt();
	    //x.nextLine();
	    String s=x.nextLine();
	    
	    int m=x.nextInt();
	    int arr[]=new int[m];
	    
	    for(int i=0;i<m;i++)
	    	arr[i]=x.nextInt(); //  a*b % c==0
	    int ans=0;
	    
	    
	  for(int k=0;k<m;k++) {
		  int length=arr[k];
		  
		 
		  for(int i=0;i<n;i++) {
			  if(length>n-i)
				  break;
			  String pre="";            
			  String pos="";
			  
			  for(int j=i;j<i+length;j++) {
				  pre+=s.charAt(j);
				  pos=s.charAt(j)+pos;
			  }
			 // System.out.println(pre+" "+pos);
			  if(pre.equals(pos)) ans++;
		  }
		  
		 // System.out.println(ans);
		  
	  }
            System.out.println(ans);
		
		
         }
								
		
	
	
public static int[] assignPrime(int arr[]){
	  for(int i=2;i<1000001;i++){
	    if(arr[i]==1){
	      for(int j=2*i;j<1000001;j+=i){
	        arr[j]=0;
	      }
	    }
	  }
	  return arr;
	}	
	
public static void sortbyColumn(int arr[][], int col) 
{ 
    // Using built-in sort function Arrays.sort 
    Arrays.sort(arr, new Comparator<int[]>() { 
        
      @Override              
      // Compare values according to columns 
      public int compare(final int[] entry1,  
                         final int[] entry2) { 

        // To sort in descending order revert  
        // the '>' Operator 
        if (entry1[col] > entry2[col]) 
            return 1; 
        else
            return -1; 
      } 
    });  // End of function call sort(). 
} 
	
	
	static class FastReader
	{
	BufferedReader br;
	StringTokenizer st;

	    public FastReader() 
	    { 
	        br = new BufferedReader(new
	                 InputStreamReader(System.in)); 
	    } 

	    String next() 
	    { 
	        while (st == null || !st.hasMoreElements()) 
	        { 
	            try
	            { 
	                st = new StringTokenizer(br.readLine()); 
	            } 
	            catch (IOException  e) 
	            { 
	                e.printStackTrace(); 
	            } 
	        } 
	        return st.nextToken(); 
	    } 

	    int nextInt() 
	    { 
	        return Integer.parseInt(next()); 
	    } 

	    long nextLong() 
	    { 
	        return Long.parseLong(next()); 
	    } 

	    double nextDouble() 
	    { 
	        return Double.parseDouble(next()); 
	    } 

	    String nextLine() 
	    { 
	        String str = ""; 
	        try
	        { 
	            str = br.readLine(); 
	        } 
	        catch (IOException e) 
	        { 
	            e.printStackTrace(); 
	        } 
	        return str; 
	    } 
	}
	
	static long findXOR(long n)
    {
        long mod = n % 4;
 
        // If n is a multiple of 4
        if (mod == 0)
            return n;
 
        // If n % 4 gives remainder 1
        else if (mod == 1)
            return 1;
 
        // If n % 4 gives remainder 2
        else if (mod == 2)
            return n + 1;
 
        // If n % 4 gives remainder 3
        else if (mod == 3)
            return 0;
        return 0;
    }
	
	static long findXOR(long l, long r)
    {
        return (findXOR(l - 1) ^ findXOR(r));
    }
	     
	 
}
