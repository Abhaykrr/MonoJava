 package cses;
import java.util.*;
import java.lang.*;
import java.io.*;
import java.util.StringTokenizer;
 
public class Main {
	
  static class FastReader
	{
	BufferedReader br;
	StringTokenizer st;

	    public FastReader() 
	    { 
	        br = new BufferedReader(new
	                 InputStreamReader(System.in)); 
	    } 

	    String next() 
	    { 
	        while (st == null || !st.hasMoreElements()) 
	        { 
	            try
	            { 
	                st = new StringTokenizer(br.readLine()); 
	            } 
	            catch (IOException  e) 
	            { 
	                e.printStackTrace(); 
	            } 
	        } 
	        return st.nextToken(); 
	    } 

	    int nextInt() 
	    { 
	        return Integer.parseInt(next()); 
	    } 

	    long nextLong() 
	    { 
	        return Long.parseLong(next()); 
	    } 

	    double nextDouble() 
	    { 
	        return Double.parseDouble(next()); 
	    } 

	    String nextLine() 
	    { 
	        String str = ""; 
	        try
	        { 
	            str = br.readLine(); 
	        } 
	        catch (IOException e) 
	        { 
	            e.printStackTrace(); 
	        } 
	        return str; 
	    } 
	}
	public static void main(String[] args) throws java.lang.Exception {

		OutputStream outputStream =System.out;
	    PrintWriter out =new PrintWriter(outputStream);
	    FastReader x =new FastReader();
	    int length=x.nextInt();
	    int w=x.nextInt();
	 ArrayList<Integer> arr=new ArrayList<>();
	 
	    
	    for(int i=0;i<length;i++) 
	    	arr.add(x.nextInt());

	  Collections.sort(arr);
int count=0;


while(arr.size()!=0) {
	int ele=arr.get(0);
	arr.remove(0);
	int toFind=w-ele;
	int found=0;
	
	int l = 0, r = arr.size() - 1; 
	int m=0;
	if(arr.size()!=0) {
    while (l <= r) { 
        m = l + (r - l) / 2; 

        
        if (arr.get(m) == toFind) {
        	found=1;
        	arr.remove(m);
        	break;
        }

        if (arr.get(m) < toFind) 
            l = m + 1; 
        else
            r = m - 1; 
    } 
    
    if(found==0&&(arr.size()!=0)) {
    	
    	while(m>=0) {
    		int curr=arr.get(m);
    		if(curr<=toFind) {
    			arr.remove(m);
    			break;
    		}
    		m--;
    	}
    	
    }
	}

    count++;
	
	
}
System.out.println(count);
	  
	
	   
	    
	 
	    
	  
	 
	        
	   out.close();
	}
   
}
