package interviewBit;

import java.util.*;

public class Two_Pointers {
	static int solve(ArrayList<Integer> A) {
        int p1=0;
        int p2=0;
        int i=0;
        HashMap<Integer, Integer> map = new HashMap<>(); 
        if(A.size()<=2)
        return 0;
        else{
            for( i=0;i<A.size();i++){
                int toAdd=A.get(i);
                
                if(map.containsKey(toAdd)==true){
                    int occurence=map.get(toAdd);
                    if(occurence==2){
                    p1=i;
                    map.replace(toAdd,occurence+1);
                    break;
                    }
                    else
                    {
                        occurence+=1;
                        map.replace(toAdd,occurence);
                    }
                }else
                map.put(toAdd,1);
                
            }
            for(int j=A.size()-1;j>i;j--){
                 int toAdd=A.get(j);
                
                if(map.containsKey(toAdd)==true){
                    int occurence=map.get(toAdd);
                    if(occurence==2){
                    p2=j;
                    map.replace(toAdd,occurence+1);
                    break;
                    }
                    else
                    {
                        occurence+=1;
                        map.replace(toAdd,occurence);
                    }
                }else
                map.put(toAdd,1);
            }
            
        }
        System.out.println(map);
      System.out.println(p1+" "+ p2);
        return (p2-p1);
    }
	
	
	public static void main(String[] args) {
	Scanner x=new Scanner(System.in);
	//int length=x.nextInt();
	ArrayList<Integer> arr=new  ArrayList<>();
	int count=0;
	while(true) {
		int toAdd=x.nextInt();
		if(toAdd==0)
			break;
			else {
	    arr.add(toAdd);
	    count++;
			}
	}
	System.out.println(count);
	System.out.println(solve(arr));

	}

}
