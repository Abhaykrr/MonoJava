package anujVro;

public class BitManipulation_2 {

	public static void main(String[] args) {
	
////////////////////////   Finding The  i th Bit Of A Number
		 
		int a=97;    // 1100001      // find the 5 th bit from left
		
		int b=1;    b=b<<5;
		                                    int c=a&b;
	
	if(c==0) {
		// i th bit is 0;
	}else {
		// i th bit is 1;
	}
		
////////////////////////Setting The  i th Bit Of A Number	
	
	a=97;     // 1100001  // Set the 5 th bit from left
	b=1;
	b=b<<5;
	
	// we now do A or B  i.e   A|b  and the respective bit will change  
	
////////////////////////Clearing The i th Bit Of A Number	
	
	a=97;    // 1100001  // Set the 6 th bit from left
	b=1;
	b=b<<6;
	b=~b;
	
	a=a&b;
	
	
	/////////////// Find the Number of bits to be Changed to convert A to B;

	a=97;                  // 1100001  
	b=47;                 //  0101111
	 c=a^b;              //  1001110     Same bits remains Zero and rest are to be changed
	 int count=0;
	 
	 while(c!=0) {         
		 if(c%2!=0)
			 count++;
		 c=c>>1;
	 }                                 // Time complexity lg2n+1 
	 
	 //            Or we can do while c%c-1 !=0 count++;   reduced time complexity 
	 //     Time complexity =no of set bits
	 // It changes the Last Significant bit of the number
	 
		 
	
	
	
	}

}
