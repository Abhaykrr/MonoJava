package anujVro;

import java.util.*;


public class Wiley_Edge {

	public static void main(String[] args) {
		
	  ArrayList<Integer> l = new ArrayList<>();
	  Stack<Integer> s =new Stack<>();
	  LinkedList<Integer> ll = new LinkedList<>();
	  Queue<Integer> q = new LinkedList<>();
	  ArrayDeque<Integer> ad = new ArrayDeque<>();
	  PriorityQueue<Integer> pq = new PriorityQueue<>(Comparator.reverseOrder());
	  
	  Set<Integer> set = new HashSet<>();
	  Set<Integer> st = new TreeSet<>();
	  Set<Integer> sl = new LinkedHashSet<>();
	  
	  Map<Integer,Integer> m = new HashMap<>();
	  Map<Integer,Integer> map = new LinkedHashMap<>();
	  Map<Integer,Integer> mp = new TreeMap<>();
	  
	  
	  m.put(1,3);
	  m.put(2,5);
	  m.put(9,2);
	  
	  set.add(1);
	  set.add(2);
	  set.add(3);
	  set.add(4);
	  

	  Iterator<Integer> i = set.iterator();
	  

	  for(Map.Entry<Integer,Integer> it :m.entrySet()) {
		  it.getKey();
	  }
	  
	  
	  int arr[]= {1,2,3,4,5,6,7};
	  
	  System.out.println(bs(arr,0,arr.length-1,3));
	  
	  
	  String a ="Z";
	  int b = a.charAt(0);
	  System.out.println(b);
	
	  System.out.println(fib(9));
	

	}
	
	static int fib(int n ) {
		
		if(n<=1) return n;
		
		else return fib(n-1) +fib(n-2);
	}
	
	
	static int bs(int[] arr ,int l, int r ,int t) {
		
		if(r>=l) {
			int mid = (l+r)/2;
			
			if(arr[mid]==t) return mid;
			
			if(arr[mid]>t) return bs( arr, l,mid-1,t); 
			
			return bs(arr,mid+1,r,t);
			
		}
		return -1;
	}

}
