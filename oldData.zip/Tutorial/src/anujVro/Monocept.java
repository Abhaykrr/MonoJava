package anujVro;
import java.util.*;

public class Monocept {

	public static void main(String[] args) {
		
		HashMap<Integer,Integer> m = new HashMap<>();
		
		for(Map.Entry<Integer, Integer> e :m.entrySet()) {
			e.getKey();
			e.getValue();
		}
		
		Set<Integer> s =  new HashSet<>();
		
		Iterator i =s.iterator();
		
		for(i.hasNext()) {
			i.next();
		}	
		
		
			

	}

}
