package trees;

import java.util.Scanner;

public class Binary_Tree {

	static Scanner x=new Scanner(System.in);
	public static void main(String[] args) {
		createTree();
	}

	
	static Node createTree() {
		Node temp=null;
		System.out.println("Enter data");
		
		int data=x.nextInt();
		if(data==-1) return  null;
		
		temp=new Node(data);
		
		System.out.println("Enter left of "+data);
		temp.left=createTree();
		System.out.println("Enter Right of "+data);
		temp.right=createTree();
		
		
		return temp;
	}
	
	static void inOrder(Node root) {
		if(root==null) return;
		inOrder(root.left);
		System.out.println(root.data);
		inOrder(root.right);
	}
	static void preOrder(Node root) {
		if(root==null) return;
		System.out.println(root.data);
		inOrder(root.left);
		inOrder(root.right);
	}
	static void postOrder(Node root) {
		if(root==null) return;
		inOrder(root.left);
		inOrder(root.right);
		System.out.println(root.data);
	}
}
class Node{
	Node left,right;
	int data;
	 Node(int data){
		 this.data=data;
		 this.left=null;
		 this.right=null;
	 }
}
