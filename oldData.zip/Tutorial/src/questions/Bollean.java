package questions;

public class Bollean {

}
