	package questions;

import java.util.Scanner;

public class AllInOne {

	public static void main(String[] args) {
	Scanner x=new Scanner(System.in);
	
	System.out.println("greatest sum of array \nbubble sort");

	int y=x.nextInt();
	switch(y)
	
		{
	case 1:
	{
		
	}
	}
		
		
		
		
	
		}
	}


