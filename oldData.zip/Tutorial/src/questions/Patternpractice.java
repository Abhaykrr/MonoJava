package questions;
import java.util.*;

public class Patternpractice {

	public static void main(String[] args) {
		Scanner x=new Scanner(System.in);
		int n=x.nextInt();
		
	           
	       
}
}