package questions;

public class Boolean {

	public static void main(String[] args) {
		int x=5;
		boolean y;
		y=!(x>4);
		System.out.println(y);
	}

}
