package questions;

import java.util.Scanner;

public class ArrayPractise {

	public static void main(String[] args) {
System.out.println("hello");
	Scanner x=new Scanner(System.in);
		 
		
		int abhay[]= new int[5];
		for(int i=0;i<5;i++) {
			abhay[i]=x.nextInt();
		}
		if(i!=42) 
		{
		for(int i=0;i<abhay.length;i++) {
			System.out.println(abhay[i]);
		}
		}
	}

}