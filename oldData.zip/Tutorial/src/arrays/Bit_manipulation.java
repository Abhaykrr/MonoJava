package arrays;

public class Bit_manipulation {
	public static int mst(int number)
    {
		return (int)(Math.log(number) /  Math.log(2) + 1); 
    }
	public static void main(String[] args) {
		
	double a=Math.pow(2,10);
	int b=(int)a;
		System.out.println(b);
		
	}

}
