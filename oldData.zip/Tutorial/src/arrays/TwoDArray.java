package arrays;

public class TwoDArray {

	public static void main(String[] args) {
		
		
		int b[][]= {
				{1,2,3,4,5},
				{78,56,23},
				{23,24,25}
		          };
		System.out.println(b[0][4]);
	}

}
