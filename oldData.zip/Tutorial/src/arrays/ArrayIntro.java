package arrays;
import codeForces.*;
public class ArrayIntro {

	public static void main(String[] args) {
		MatrixAdd obj = new MatrixAdd();
		Pa d =new Pa();
//		int[] marks =new int[5];
		
		
//		int[] marks;
//		marks =new int[5];
		
//		int marks[] =new int[5];
//		int marks[],roll[];
//		System.out.println(marks[4]);
		int[] age = {1,2,3,4,5};
		age[1]=9;
	
		for(int i=0;i<age.length;i++){
             System.out.println(age[i]);
              }
}
}