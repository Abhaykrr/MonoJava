package arrays;
import java.util.*;
import java.util.Collections;


public class Sorting {

	public static void main(String[] args) {
	
		
		String  a= "I Am Abhay";
		
		for(String x :a.split(" ")) {
			System.out.println(x);
		}
		
		Scanner x= new Scanner(System.in);
		
		
		
	}
	
	
}
