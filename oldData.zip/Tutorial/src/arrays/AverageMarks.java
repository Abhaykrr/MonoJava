package arrays;

import java.util.Scanner;

public class AverageMarks {

	public static void main(String[] args) {
		int n=9;
		String a=(int)n;
	}
	
	

}
