package arrays;

public class Morrie_Voting_Algorithm {

	public static void main(String[] args) {
		int arr[]= {2,2,3,4,2,2,4,2,2,4,2,1,2,3};
		int count=1;
		int curr=0;
		System.out.println(arr.length);
		for(int i=0;i<arr.length-1;i++) {
			if(count<=0) {
				curr=arr[i];
			}
			if(curr==arr[i+1]) {
				count++;
			}else
				count--;
		}
		
		System.out.println(curr);
				

	}

}
