package arrays;

public class First_Missing_pos_No {

	static int missingNumber(int arr[], int size)
    {
        int ans=0;
        int count=0;
       for(int i=0;i<size;i++){
           if(arr[i]>0)
           while(arr[i]>0&&arr[i]<=size&&arr[i]!=i+1){
               int curr=arr[i];
               
               int temp=arr[curr-1];
               count++;
               arr[i]=temp;
               arr[curr-1]=curr;
           }
           if(count==size) {
        	   break;
           }
           
       }
       
       for(int i=0;i<size;i++){
           if(arr[i]!=i+1){
           ans=i+1;
           break;
           }
       }
       
       if(ans==0)
       ans=size+1;
       return ans;
    }
	public static void main(String[] args) {
		int arr[]= {0,-10,1,3,-20};
		int size=arr.length;
		
		
		System.out.println(missingNumber(arr,size));

	}

}
