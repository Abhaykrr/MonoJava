package list;

import java.util.*;

public class Hashmap {

	public static void main(String[] args) {
		HashMap<Integer,Integer> mp=new HashMap<>();
    Scanner x=new Scanner(System.in);
System.out.println(-3%3);
    
    
    
  
    	int length=x.nextInt();
    	int arr[]=new int[length];
    	
    	for(int i=0;i<length;i++)
            arr[i]=x.nextInt();
    	
    	for(int i=0;i<length;i++) {
    		
    		for(int j=0;j<length;j++) {
    			if(j!=i) 
    			if((arr[i]-arr[length])%(j-i)==0&&(arr[i]-arr[length])/(j-i)>0) {
    				
    			}
    			
    					
    					
    					
    			
    			
    		}
    		
    		
    	}
    	
    	
    	
    	
    	
    
	
		
		
///////////////////////////////////////////////	
	}

}
