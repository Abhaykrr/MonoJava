package cp_UA_Number_Theory;

import java.util.Arrays;

public class Sieve_Of_Eratosthenes {

	public static void main(String[] args) {
	long no=10000000;
	int arr[]=new int[10000001];
	Arrays.fill(arr, 0);
	
	for(int i=2;i<no+1;i++) {
		if(arr[i]!=-1)
		for(int j=2*i;j<no+1;j+=i) 
			arr[j]=-1;
			
		
	}
	System.out.println(arr[37]);
	}

}
