package wiley;

import java.util.*;

public class Pattern {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int f = 2;
        for (int i = 1; i < 2 * n; i++) {
            for (int j = 1; j < 2 * n; j++) {
                if (i == j || i + j == 2 * n) {
                    if (i <= n) {
                        System.out.print(i + " ");
                        if (j >= n) {
                            break;
                        }
                    } else {
                        if (j <= n) {
                            System.out.print(i - f + " ");
                            f++;
                        } else {
                            System.out.print(i - f + 1 + " ");
                            f++;
                            break;
                        }
                    }
                } else {
                    System.out.print("  ");
                }
            }
            System.out.println();
        }
		
	}
	
}

//n=input()
//s=input()
//c=0
//for i in range(0,len(n)):
//    if n[i]=='?' and s[i]=='?':
//        pass
//    elif n[i]==s[i]:
//        pass
//    elif n[i]=='?' and s[i].isalpha():
//        pass
//    elif n[i].isalpha() and s[i]=='?':
//        pass
//    else:
//        c=c+1
//m=0
//for i in range(0,len(n)):
//    if n[i]!=s[i]:
//        m=m+1
//    elif n[i].isalpha() and s[i]=='?':
//        m=m+1
//    elif n[i]=='?' and s[i]=='?':
//        m=m+1
//    elif n[i].isalpha() and s[i].isalpha():
//        if n[i]==s[i]:
//            pass
//print(c,m)  





//def f(a):
//    if a[-1].isdigit():
//        n=len(a)-1
//        c=str(n)
//        if len(c) ==9:
//            return -1
//        if c[0]==a[-1]:
//            return c[1]
//    
//    if len(str(len(a))) ==9:
//        return -1
//    return a*str(len(a))    
//    
//a=input()
//print(f(a))
