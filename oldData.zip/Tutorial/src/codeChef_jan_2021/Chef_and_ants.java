package codeChef_jan_2021;

import java.util.*;

public class Chef_and_ants {

	public static void main(String[] args) {
		Scanner x=new Scanner(System.in);
		int test=x.nextInt();
		
		while(test-->0) {
			long n=x.nextLong();
			
			Set<Integer> p=new HashSet<>();
			Set<Integer> g=new HashSet<>();
			
		int length=x.nextInt();
		
		for(int i=0;i<length;i++) {
			int toAdd=x.nextInt();
			if(toAdd>0) 
				p.add(toAdd);
			else
				g.add(toAdd);
			
		}
		
		long ans=0;
		long min1=Math.min(g.size(), p.size());
		long max1=Math.max(g.size(), p.size());
		max1-=1;
		
		if(max1==min1)
			ans=min1*max1;
		else {
			while(min1>0) {
				ans+=min1;
				ans+=max1;
				max1--;
				min1--;
			}
		}
		System.out.println(ans);
		
			
		}

	}

}
