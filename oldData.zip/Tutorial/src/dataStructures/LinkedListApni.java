package dataStructures;

import java.util.*;
import java.util.LinkedList;
import dataStructures.MyLinkedList.Node;

public class LinkedListApni {
	
	public static void main(String[] args) {
		MyLinkedList ll=new MyLinkedList();
		

   ll.add(1);
   ll.add(2);
   ll.add(3);
   ll.add(4);
   ll.add(11);
   ll.add(12);
   
   ll.show();
   
 
   
   
	
	//System.out.println(ll.ispallindrome());
      //	ll.add(6);
	  // 1 4 2 5 3 6 ,,,,,,,,,,,,,,,,,,, 

	//ll.show();
	//ll.delduplicates(ll.head);
        //ll.head=	ll.reverseR(ll.head);
	//   ll.show();
//	ll.show();
	//ll.reversePrint(ll.head);
	
//	ll.addDoubly(1);
//	ll.addDoubly(2);
//	ll.addDoubly(3);
//	ll.addDoubly(4);
//	
	//ll.showDoubly();
//	 ll.reverseDoubly();
	
	
	
	
	
	
	}
	
}	



	

	


