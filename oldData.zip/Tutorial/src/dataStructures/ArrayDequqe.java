package dataStructures;

import java.util.*;
//  Sliding Window Maximum Hacker Rank And Leet Code
public class ArrayDequqe {

	public static void main(String[] args) {
	ArrayDeque<Integer> dq=new ArrayDeque<>();
       int arr[]= {10, 8, 7, 6 , 5, 4, 3, 2, 1};
       int k=3;
       int n=arr.length-k+1;
       int ans[]=new int[n];
       
       for(int i=0;i<arr.length;i++) {
    	   
    	   
       }
       
       
       

	System.out.println(dq);
	}
	

}
