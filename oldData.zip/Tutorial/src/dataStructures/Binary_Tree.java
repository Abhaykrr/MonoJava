package dataStructures;

import java.util.*;

public class Binary_Tree {
	
	public static void main(String[] args) {
		Node root=Node.CreateTree();
	
	/*
	 * inOrder     LNR
	 * preOrder   NLR
	 * postOrder  LRN
	 */
		
	}

}

class Node{
	int data;
	Node left,right;
	
	Node(int data){
		this.data=data;
	}
	private static int[] arr=new int[2];
	static Node CreateTree() {
		Scanner x=new Scanner(System.in);
		Node root=null;
		int data=x.nextInt();
		
		if(data==-1) return null;
		root=new Node(data);
		
		System.out.println("Enter left "+ data);
		root.left=CreateTree();
		
		System.out.println("Enter right "+ data);
		root.right=CreateTree();
		
		
		return root;
		
	}
	static void inOrder(Node root) {
		if(root==null) return ;
		inOrder(root.left);
		System.out.print(root.data+" ");
		inOrder(root.right);
		
	}
	static void preOrder(Node root) {
		if(root==null) return ;

		System.out.print(root.data+" ");
		preOrder(root.left);
		preOrder(root.right);
		
	}
	static void postOrder(Node root) {
		if(root==null) return ;
		postOrder(root.left);
		postOrder(root.right);
		System.out.print(root.data+" ");
		
	}
	static void levelOrder(Node root) {
		if(root==null)return ;
		 Queue<Node> q   = new LinkedList<>(); 
		 q.add(root);
		 
		 while(q.size()!=0) {
			 
			 while(q.size()!=0) {
				 System.out.print(q.peek().data+" ");
				 if(q.peek().left!=null)
				 q.add(q.peek().left);
				 if(q.peek().left!=null)
				 q.add(q.peek().right);
				 q.remove();
			 }
			 
			 
		 }
	}
	
	 static int diameterOfBinaryTree(Node root) {
		 if(root==null)return 0;
		 
		 int left=diameterOfBinaryTree(root.left);
		 int right=diameterOfBinaryTree(root.right);
		 Node.arr[0]=left;
		 arr[1]=right;
	        return 1+Math.max(left, right);
	    }
	
	
}
