package dataStructures;
import dataStructures.CustomLinkedList.Node;
public class Custom_LL {

	public static void main(String[] args) {
		CustomLinkedList ll=new CustomLinkedList();
		
	
	    ll.Add(1);
		ll.Add(2);
		ll.Add(3);
		ll.Add(4);
		ll.Add(5);
		ll.Print();
		
		
                                       

		
	

		

	}

}
