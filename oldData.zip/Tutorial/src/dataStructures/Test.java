package dataStructures;

import java.util.*;

public class Test {

	public static void main(String[] args) {
	
		Stack<Integer> st=new Stack			();
		LinkedList<Integer> ll=new LinkedList<>();
	}

}
