package multiThreading;

import java.util.*;

public class OddEven_SYNC {
	
	public static int n =10;

	public static void main(String[] args) {

  
		odd o = new odd();
		o.start();
		
		
	}
	
	

}
class even extends Thread{
	
	public void run() {
		for(int i=2;i<=10;i+=2) {
			System.out.println(i);
			
			synchronized(this) {
				this.notify();
			}
		}
	}
}


class odd extends Thread {
	
	even e = new even();
	
	public void run() {
		for(int i=1;i<=10;i+=2) {
			System.out.println(i);
			if(i==1) e.start();
			try {
			synchronized(this) {
				e.wait();
			}
			}catch(Exception e) {
				
			}
		}
	}
}

