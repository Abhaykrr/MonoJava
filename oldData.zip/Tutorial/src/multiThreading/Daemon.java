package multiThreading;

public class Daemon {

	public static void main(String[] args) {
		
		Tit t = new Tit();
		t.setDaemon(true);
		t.start();

	}

}

class Tit extends Thread{
	
	public void run() {
		for(int i=0;i<5;i++) {
			System.out.println(i);
		}
	}
	
}
