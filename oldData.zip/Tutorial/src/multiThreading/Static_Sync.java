package multiThreading;


public class Static_Sync {

	
	
	
	public static void main(String[] args) {
		
		Theatr a= new Theatr();
		Theatr b= new Theatr();
		
		Thread1 t1= new Thread1(a,2);
		Thread1 t2= new Thread1(a,1);
		Thread1 t3= new Thread1(a,5);
		Thread1 t4= new Thread1(a,5);
	
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		
	
		
		

	}

}

class Thread1 extends Thread{
	
	int seats;
	Theatr n;
	
	 Thread1(Theatr n,int seats) {
		this.n=n;
		this.seats=seats;
	}
	
	public void run() {
		n.bookTicket(seats);
	}
}

//
//class Thread2 extends Thread{
//	
//	int seats;
//	Theatr n;
//	
//	 Thread2(Theatr n,int seats) {
//		this.n=n;
//		this.seats=seats;
//	}
//	
//	public void run() {
//		n.bookTicket(seats);
//	}
//}


class Theatr {
	static int totalSeats=10;
	
	synchronized static void bookTicket(int seats) {
		
		if(totalSeats>=seats) {
			System.out.println(seats+  " Booked");
			totalSeats-=seats;
			System.out.println(totalSeats+" Left Seats");
		}else {
			System.out.println("No enough seats :Available Setas "+totalSeats);
		}
		
	
	}
}
