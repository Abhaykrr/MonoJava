package multiThreading;

public class Test extends Thread{
	
	public void run() {
		for(int i=0;i<5;i++) {
			System.out.println(i+" "+ Thread.currentThread().getName());
		}
	}

	public static void main(String[] args) {
		
			Test t =new Test();
			Test t1=new Test();
			
			t.start();
			
			for(int i=0;i<5;i++) {
				System.out.println(i);
			}
	}

}


