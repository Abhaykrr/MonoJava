package multiThreading;

public class Wait_Notify_NotifyALL {

	public static void main(String[] args) throws Exception {
		
		Total t = new Total();
		t.start();
		
		synchronized(t) {
			t.wait();
		}
		System.out.println(t.total);
	}

}


class Total extends Thread {
	 int total;
	 
	public void run() {
		
		synchronized(this) {
			for(int i=0;i<10;i++) {
				total+=100;
			}
			
			this.notify();
		}
		
	}
}
