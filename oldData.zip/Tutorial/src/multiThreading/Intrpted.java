package multiThreading;

public class Intrpted {

	public static void main(String[] args) {
		
		Test3 t = new Test3();
		t.start();
		t.interrupt();

	}

}

class Test3 extends Thread{
	public void run() {
		
		System.out.println(Thread.interrupted());
		System.out.println(Thread.interrupted());
		System.out.println(Thread.interrupted());
		System.out.println(Thread.interrupted());
		try {
			
			for(int i=0;i<5;i++) {
				System.out.println(i);
				Thread.sleep(1000);
			}
			
		}catch(Exception e) {
			System.out.println(e);
		}
	
	}
}
