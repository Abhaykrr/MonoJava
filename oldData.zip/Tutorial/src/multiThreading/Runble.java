package multiThreading;

public class Runble implements Runnable{
	
	public void run() {
		System.out.println("Child Thread");
	}

	public static void main(String[] args) {
		Runble r = new Runble();
		Thread t = new Thread(r);
		
	}

}


//class Test implements Runnable{
//	public void run() {
//		System.out.println("Child Thread");
//	}
//}
