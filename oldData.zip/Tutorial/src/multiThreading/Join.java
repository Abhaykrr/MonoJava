package multiThreading;

public class Join extends Thread {
	
	static Thread x;
	
	public void run() {
		for(int i=0;i<5;i++) {
			System.out.println(i);
		}
	}
	
	public static void main(String [] args) throws Exception {
		
		Join j = new Join();
		Test1 t = new Test1();
		x=t;
		t.start();
		
		t.join(3000);
		j.start();
		
		
			for(int i=0;i<5;i++) {
				System.out.println(i);
			}
		
	}

}

class Test1 extends Thread{
public void run() {
	System.out.println("Child Thread");
}
}
