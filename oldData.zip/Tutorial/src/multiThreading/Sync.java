package multiThreading;

public class Sync extends Thread{
	
	static Theater t;
	int seats;
	
	public void run() {
		t.bookTicket(seats);
	}

	public static void main(String[] args) {
		
		t=new Theater();
		
		Sync a= new Sync();
		a.seats=5;
		
		Sync b= new Sync();
		b.seats=8;
		
		a.start();
		b.start();
		

	}

}


class Theater {
	static int totalSeats=10;
	
	synchronized void bookTicket(int seats) {
		
		if(totalSeats>=seats) {
			System.out.println(seats+  " Booked");
			totalSeats-=seats;
			System.out.println(totalSeats+" Left Seats");
		}else {
			System.out.println("No enough seats :Available Setas "+totalSeats);
		}
		
	
		
		synchronized(this) {
			// synchronized block 
		}
	}
}
