package cp_UA_Arrays;

import java.util.ArrayList;

public class SquareRoot_Decomposition {

	public static void main(String[] args) {
		ArrayList<Integer> prefix =new ArrayList<>();
		int arr[]= {3,9,1,3,10,5,7,2,11,0,-1};
		int l1=(int)Math.sqrt(arr.length);
		int l=2;
		int r=10;
	 
	   
	  
	    int count=0;
	    int min=Integer.MAX_VALUE;
	    for(int i=0;i<arr.length;i++) {
	    	
	    	if(arr[i]<min) {
	    		min=arr[i];
	    	}
	    	count++;
	    	if(count%l1==0) {
	    	  prefix.add(min);
	    		min=Integer.MAX_VALUE;
	    	}
	    	
	    	
	    }
	    prefix.add(min);
	for(int i=l/l1;i<l/l1+1;i++) {
		
	}
	    
	
	    
	}

}
