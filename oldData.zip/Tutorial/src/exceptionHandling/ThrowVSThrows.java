package exceptionHandling;

import java.io.FileInputStream;

public class ThrowVSThrows {

	public static void main(String[] args)  {
		
		try {
			FileInputStream a =new FileInputStream("d:/abc.txt");
			throw new YoungerAgeException("demo");
		}catch(Exception e) {
			System.out.println(e);
		}
		
		
		

	}

}

class YoungerAgeException extends RuntimeException{
	
	YoungerAgeException(String msg){
		super(msg);
	}
}
