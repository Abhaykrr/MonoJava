package exceptionHandling;

public class Try_Catch_Finally {

	public static void main(String[] args) {
		
		try {
			
			try {
				try {
					
				}catch(Exception e){
					
				}finally {
					
				}
			}catch(Exception e){
				try {
					
				}catch(Exception f	){
					
				}finally {
					
				}
			}finally {
				try {
					
				}catch(Exception e){
					
				}finally {
					
				}
			}
			
		}catch(Exception e){
			
		}finally {
			
		}
	}

}
