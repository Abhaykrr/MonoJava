package exceptionHandling;

public class Throw {

	public static void main(String[] args) {
		
		int age = 17;
		
		try {
			if(age<18) {
				throw new YoungerAgeException("Age less than 18 cant vote");
				
			}else {
				System.out.println("Good");
			}
		}catch(YoungerAgeException e) {
			e.printStackTrace();
		}
		
		System.out.println("Voting Done");
		
	}

}

class YoungerAgeException extends RuntimeException{
	
	YoungerAgeException(String msg){
		super(msg);
	}
}
