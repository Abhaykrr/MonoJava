package exceptionHandling;

public class SOP {

	public static void main(String[] args) throws Exception {
		
		try {
			int a=10;
			int b=0;
			int c=a/b;
			
		}catch(ArithmeticException e) {
			e.printStackTrace();
//			System.out.println("Break");
//			System.out.println(e);
//			System.out.println("Break");
//			System.out.println(e.toString());
//			System.out.println("Break");
//			System.out.println(e.getMessage());
		}
		
		int d=200/0;
		System.out.println();
		System.out.println("Done");

	}

}
