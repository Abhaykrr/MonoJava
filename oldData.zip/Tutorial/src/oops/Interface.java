package oops;

public class Interface {

	public static void main(String[] args) {
//		transform s=new transform();
//		bycycle b=new transform();
//		System.out.println(b.a);
		
	}

}

interface bycycle{
    int a=30;
//   void brake();
//	void horn();
	default void speed() {
		
	}
	private void gear() {
		
	}
	
	
}

interface car{
	 int a =40;
	void brake();
	void horn();
}

class bike{
	int a=10;
	void brake() {
		
	}
	void horn() {
		
	}
}

//class transform extends bike implements car ,bycycle{
//
//	@Override
//	public void brake() {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void horn() {
//		// TODO Auto-generated method stub
//		
//	}
//	
//}
