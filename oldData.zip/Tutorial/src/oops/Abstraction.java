package oops;

public class Abstraction {

	public static void main(String[] args) {
	 Shape a=new circle();
	  a.showColor();
	  	
		rectangle r=new rectangle();
		r.showColor();
		
	}

}
abstract class Shape{
	
    abstract void color();
	 void showColor() {
		System.out.println("Showing Color");
	 }
}
class circle extends Shape{
	  void color() {
	    	 
	     }
	  
}
class rectangle extends circle{
	
}
