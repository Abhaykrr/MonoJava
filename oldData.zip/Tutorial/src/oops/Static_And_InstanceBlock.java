package oops;

public class Static_And_InstanceBlock {

	public static void main(String[] args) {
		Pen p1=new Pen();
		Pen p2=new Pen();
	}

}
// Static instance is called only once when the class object is created
class Pen{
	{System.out.println("Hell0");}
     static{ System.out.println("First");}
     Pen(){
    	 System.out.println("Agya");
     }
}
