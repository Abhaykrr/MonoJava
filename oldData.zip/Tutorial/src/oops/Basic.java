package oops;


public class Basic {

	
	int diff;
	
	public static void main(String[] args) {
		
		Student s1=new Student(10);
		Teacher t1=new Teacher(10);
		Basic b1=new Basic();
		Principal p1=new Principal(10);
		
		
	}

}

class Teacher extends Student {
	
	Teacher(int data) {
		super(data);
	}
//	
//	void Help() {
//		System.out.println("mu me le");
//	}
//	
}

class Student {
	
	int marks;
	

	 Student(int data){
		
		 this.marks=data;
	}
	 
	  void Help() {
		System.out.println("Lwda help"); 
	 }
	  
	  public void print(int marks) {
		  
	  }
	  
	  static void print(int marks) {
		  
		  
	  }
	
}

class Principal extends Teacher {

	Principal(int data) {
		super(data);
	}
	
	void Help() {
	super.Help();
	}
	
}
