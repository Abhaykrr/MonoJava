package oops;

public class Constructors {

	public static void main(String[] args) {
		Parent p=new Child();
	//	System.out.println(b.a);
        
	}

}
abstract class Parent {
    Parent(){
        System.out.println("Parent Class");
    }
    abstract void display();
}

 class Child extends Parent {
    Child() {
        System.out.println("Child Class");
    }
    
      void display() {
    	
    	
    }
    }