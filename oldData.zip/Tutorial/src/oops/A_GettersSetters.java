package oops;

public class A_GettersSetters {

	
	
	public static void main(String[] args) {
	
		Employee e1=new Employee();
		e1.setName("abhay");
		System.out.println(e1.getname());
	}

}

class Employee{
	private int id;
	private String name;
	static int cid;
	
	
	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public String getname() {
		return name;
	}

	
}
