package oops;

public class Interface_Polymorphism {

	public static void main(String[] args) {
		Animal boy=new Human();
		boy.poty();  
	}

}

class Monkey{
	void eat() {
		System.out.println("Eating....");
	}
	void sleep() {
		System.out.println("Sleeping...");
	}
}

interface Animal {
	void poty();
	void sex();
}

class Human extends Monkey implements Animal{
	void run() {
		System.out.println("Runnuing...");
	}

	@Override
	public void poty() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sex() {
		// TODO Auto-generated method stub
		
	}
	
}
