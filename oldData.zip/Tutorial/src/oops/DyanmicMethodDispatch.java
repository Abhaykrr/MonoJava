package oops;

public class DyanmicMethodDispatch {

	public static void main(String[] args) {
		Phone a=new SmartPhone();
		a.on();
		a.off();
 //		a.music();
	}

}

class Phone{
	void on() {
		System.out.println("Turning On");
	}
	
	void off() {
		System.out.println("Turning Off");
	}
	
}

class SmartPhone extends Phone{
	void music() {
		System.out.println("Playing Music");
	}
	
	void on() {
		System.out.println("Turning on smartPhone");
	}
}
