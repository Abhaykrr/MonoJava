package oops;

public class AccessModifiers {

	public static void main(String[] args) {
		System.out.println(demo.run());
	}

}
class demo{
	public int a=10;
	static int run() {
		System.out.println("fmkoff");
		return 0;
	}
}
