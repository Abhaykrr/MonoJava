package encapuslation;

public class EncapuslationIntro {

	public static void main(String[] args) {
	
		Student abhay=new Student();
		abhay.name(20);
		//abhay.setname(20);
		abhay.printname();
	}
}
