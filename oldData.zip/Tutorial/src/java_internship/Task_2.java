package java_internship;

import java.util.Arrays;

public class Task_2 {
	static long arr[]=new long[101];
	   static long fib(int n,long [] arr)
	    {
		   if(arr[n]!=-1) 
			   return arr[n];
		   
	    if (n==0||n==1)
	       return n;
	    
	    long result =fib(n-1,arr) + fib(n-2,arr);
	    arr[n]=result;
	    return result;
	    }
	   
	public static void main(String[] args) {
	
	Arrays.fill(arr, -1);
	 System.out.println(fib(100,arr));
	}

}
