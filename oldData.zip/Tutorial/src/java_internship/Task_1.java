package java_internship;
import java.util.ArrayList;
import java.util.Scanner;

public class Task_1 {
	
	public static String reverse(String s) {
		String rev_String="";
		
		for(int i=s.length()-1;i>=0;i--) 
			rev_String+=s.charAt(i);
		
		return rev_String;
	}

	public static void main(String[] args) {
		Scanner x=new Scanner(System.in);
		String s=x.nextLine();
		
		ArrayList<String> reversed=new ArrayList<>();
		String curr="";
		
		for(int i=0;i<s.length();i++) {
			
			if(s.charAt(i)==' ') {
				reversed.add(reverse(curr));
				curr="";
			}
			if(s.charAt(i)!=' ')
			curr+=s.charAt(i);
			
		}
		
		reversed.add(reverse(curr));
		
		while(reversed.size()!=0) {
			   if(reversed.size()!=0) {
				System.out.print(reversed.get(reversed.size()-1)+" "); 
			   reversed.remove(reversed.size()-1);
			   }
			
			   if(reversed.size()!=0) {
				System.out.print(reversed.get(0)+" ");
			   reversed.remove(0);
			   }
			
		}
		
	}

}
