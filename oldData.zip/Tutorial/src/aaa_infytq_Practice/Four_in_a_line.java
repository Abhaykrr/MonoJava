package aaa_infytq_Practice;

import java.util.ArrayList;
import java.util.*;

//Problem Statement -: Given a m x n matrix inmatrix of positive integers, print an integer outnum based on the below logic: 
//
//Identify all possible sets in inmatrix that contain at least four consecutive elements of the same value val, either horizontally, vertically, or diagonally 
//If only one set of consecutive elements is identified, store the value val in outnum 
//If more than one set of consecutive elements is identified, find the smallest value and store it in outnum 
//If no set of four consecutive elements of the same value is identified either horizontally, vertically, or diagonally, print -1 
//Assumption: 
//m and n will be greater than 3 

public class Four_in_a_line {

	public static void main(String[] args) {
		
		Scanner x=new Scanner(System.in);
		
		int m=x.nextInt();
		int n=x.nextInt();
		
		int a[][]=new int[m][n];
		ArrayList<Integer> ll=new ArrayList<>();
		int count=0;
		
		for(int i=0;i<m;i++) {
			for(int j=0;j<n;j++) {
				a[i][j]=x.nextInt();
			}
		}
		
		for(int i=0;i<m;i++) {
			for(int j=0;j<n;j++) {
				
				
				if(j+3<n)
				if(a[i][j]==a[i][j+1]&&a[i][j]==a[i][j+2]&&a[i][j]==a[i][j+3])
					ll.add(a[i][j]);
				
				if(i+3<m)
				if(a[i][j]==a[i+1][j]&&a[i][j]==a[i+2][j]&&a[i][j]==a[i+3][j])
						ll.add(a[i][j]);
				
				if(i+3<m&&j+3<n)
				if(a[i][j]==a[i+1][j+1]&&a[i][j]==a[i+2][j+2]&&a[i][j]==a[i+3][j+3])
					ll.add(a[i][j]);
				
				if(i+3<m&&j-3<n&&j-3>=0)
				if(a[i][j]==a[i+1][j-1]&&a[i][j]==a[i+2][j-2]&&a[i][j]==a[i+3][j-3])
						ll.add(a[i][j]);
				
				
			}
		}
		
		
		
		
//
//		for(int i=0;i<m;i++) {
//			for(int j=0;j<n;j++){
//				if(i+3<m&&j-3<n)
//				if(a[i][j]==a[i+1][j-1]&&a[i][j]==a[i+2][j-2]&&a[i][j]==a[i+3][j-3])
//					ll.add(a[i][j]);
//			}
//		}
		
		Collections.sort(ll);
		
		System.out.println(ll);
		
		
	}

}
