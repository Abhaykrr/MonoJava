//package aaa_infytq_Practice;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

public class Concat {
	public static long getMaxArea(Long[] arr, long k) 
	   {
	       int n = (int) k;
	       Stack<Long> stackVal = new Stack<>();
	       Stack<Integer> stackKey = new Stack<>();
	       long[] resultArr = new long[n];
	       
	       for (int i = 0; i < n; i++) {
	       
	           while (!stackVal.empty() && stackVal.peek() >= arr[i]) {
	               
	               stackVal.pop();
	               stackKey.pop();
	               
	           }
	           
	           if (stackVal.empty()) {
	               resultArr[i] = -1;
	           }
	           
	           else {
	               resultArr[i] = stackKey.peek();
	           }
	           
	           stackVal.push(arr[i]);   
	           stackKey.push(i);   
	               
	       }
	       
	       stackKey.clear();
	       stackVal.clear();
	       
	       for (int i = n-1; i >= 0; i--) {
	           
	           long temp = resultArr[i];
	           
	           while (!stackVal.empty() && stackVal.peek() >= arr[i]) {
	               stackVal.pop();
	               stackKey.pop();
	           }
	           
	           if (stackVal.empty()) {
	               resultArr[i] = n  - (temp + 1);
	           }
	           
	           else {
	               resultArr[i] = stackKey.peek() - (temp + 1);
	           }
	           
	           stackVal.push(arr[i]);
	           stackKey.push(i);
	           
	       }
	       
	       long max = Long.MIN_VALUE;
	       
	       for (int i = 0 ; i < n; i++) {
	           
	           resultArr[i] *= arr[i];
	           max = Math.max(max, resultArr[i]);
	           
	       }
	       
	       
	       return max;
	   }
	public static void main(String[] args) {
		Scanner x=new Scanner(System.in);
	
		int length=x.nextInt();
		int h=x.nextInt();
		int b=x.nextInt();
		
		Long arr[]=new Long[length];
		
		for(int i=0;i<length;i++) arr[i]=x.nextLong();
		long area=getMaxArea(arr,length);
		long ans=area*b*h;
		long count=0;
		for(int i=0;i<length;i++) {
			count+=arr[i]*b*h;
		}
		
		System.out.println(Math.abs(ans-count)%1000000007);
		
	}

}
