package aaa_infytq_Practice;

import java.util.*;

public class twodArray {

	public static void main(String[] args) {
	
		int a=1,b=7,c=13;
		
		c=(b+1)^a;
		a=(5&2)&c;
		
		a=(b+7)+b;
		System.out.println(a+b+c);
//		Integer arr[]= {1,-1,9,2,5,4};
//		
//		Arrays.sort(arr,Collections.reverseOrder());
		
		
//		System.out.println(Math.abs(-2));
//		PriorityQueue<Integer> pq=new PriorityQueue<>();
//		pq.add(20);
//		pq.add(1);
//		pq.add(30);
//		pq.remove(20);
//		
//		System.out.println(pq.peek());
		
		
		
//	ArrayList<Integer> a = new ArrayList<>();
//	Deque<Integer> d = new LinkedList<>();
//	a.add(1);
//	a.add(2);a.add(3);a.add(9);a.add(1);
//	
//	Collections.sort(a,Comparator.reverseOrder());
//	System.out.println(a);
//	
	
		
//   Map<Integer,Integer> m =new TreeMap<>();
//   m.put(20,3);
//   m.put(1,2);
//  
//   
//   PriorityQueue<Integer> s =new PriorityQueue<>(Comparator.reverseOrder());
//   Stack<Integer> u= new Stack<>();
//   s.add(1);
//   s.add(4);
//   s.add(10);
//   s.add(0);
//   
//   int a= s.poll();
//   
//   System.out.println(a);
//   
//   
   
//   System.out.println(m.containsKey(1));
//   System.out.println(m.containsValue(1));
//		
//	System.out.println(m);
//   
//   System.out.println(m.get(0));
//   
//   for(Map.Entry<Integer, Integer> it :m.entrySet()) {
//	   System.out.println(it.getKey());
//	   System.out.println(it.getValue());
//   }
   
//   Set<Integer> s= new HashSet<>();
//   s.add(1);
//   s.add(100);
//   s.add(0);
//   
//   System.out.println(s);
//   for(Integer it:s) {
//	   System.out.println(it);
//   }
	

}
}
