package aaa_infytq_Practice;

import java.util.*;
import java.util.Scanner;

public class Rought {

	public static void main(String[] args) {
		
int a[][]=new int[5][4];
for(int i=0;i<5;i++) {
	for(int j=0;j<4;j++) {
		System.out.print(a[i][j]+" ");
	}
	System.out.println();
}
	}
	static int[][] replaceDiagonals(int mat[][]){
		int ans[][]=mat;
		
		int l=mat.length;
		int r=mat[0].length;
		
		for(int i=0;i<l;i++) {
			for(int j=0;j<r;j++) {
				if(i==j) {
					int temp=0;
					if(i-1>=0)temp+=mat[i-1][j];
					if(i+1<l) temp+=mat[i+1][j];
					if(j+1<r)temp+=mat[i][j+1];
					if(j-1>=0)temp+=mat[i][j-1];
					
					if(i-1>=0&&j-1>=0) temp+=mat[i-1][j-1];
					if(i-1>=0&&j+1<r) temp+=mat[i-1][j+1];
					
					if(i+1<l&&j-1>=0)temp+=mat[i+1][j-1];
					if(i+1<l&&j+1<r)temp+=mat[i+1][j+1];
					
					
					
					
					mat[i][j]=temp;
				}
			}
		}
		return ans;
	}
	
	static long fac(int n ,int m) {
		long ans=0;
		ans=f(n)/f(m);
		
		return ans;
		
	}
	
	 static long f(long n)
	    {
	        if (n == 0)
	            return 1;
	 
	        return n * f(n - 1);
	    }


}
