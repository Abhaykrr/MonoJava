package aaa_infytq_Practice;

import java.util.*;

// If zero is found then that row and coloum  elemnts should be zero
public class Zero_Matrix {
	
	
	static void change(int arr[][],int i,int j,int n) {
	
		for(int k=0;k<n;k++) {
			arr[i][k]=0;
			arr[k][j]=0;
		}
		
		
		
		
	}

	public static void main(String[] args) {
		
		Scanner x=new Scanner(System.in);
		int n=x.nextInt();
		
		int arr[][]=new int[n][n];
		
		for(int i=0;i<n;i++) {
			for(int j=0;j<n;j++) {
				arr[i][j]=x.nextInt();
			}
		}
		
		ArrayList<Integer> ll=new ArrayList<>();
		
		for(int i=0;i<n;i++) {
			for(int j=0;j<n;j++) {
				if(arr[i][j]==0) {
					ll.add(i);
					ll.add(j);
				}
			}
		}
		
		while(ll.size()!=0) {
			change(arr,ll.get(0),ll.get(1),n);
			ll.remove(0);
			ll.remove(0);
		}
		
		for(int i=0;i<n;i++) {
			for(int j=0;j<n;j++) {
				System.out.print(arr[i][j]+" ");
			}
			System.out.println();
		}
		
		
		
	}

}
