package aaa_infytq_Practice;

import java.util.Scanner;

//Problem Statement-: For a given positive number num, identify the palindrome formed by performing the following operations-
//
//Add num and its reverse 
//Check whether the sum is palindrome or not. If not, add the sum and its reverse and repeat the process until a palindrome is obtained 

public class Identify_pallindrome {
       public static void main(String[] args) {
		
    	   Scanner x=new Scanner(System.in);
    	   
    	   int n=x.nextInt();
    	   
    	   int curr=n;
    	   
    	   while(curr!=reverse(curr)) {
    		   curr+=reverse(curr);
    	   }
    	
    	   System.out.println(curr);
    	   
	}
       
      
       
       static int reverse(int n) {
    	   int ans=0;
    	   while(n>0) {
    		   int last=n%10;
    		   ans=ans*10;
    		   ans+=last;
    		   n/=10;
    	   }
    	   return ans;
       }
}
