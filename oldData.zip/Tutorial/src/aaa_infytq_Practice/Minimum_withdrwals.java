package aaa_infytq_Practice;
//Problem Statement-: There is a unique ATM in Wonderland. 
//Imagine this ATM as an array of numbers.
//You can withdraw cash only from either ends of the array. 
//Sarah wants to withdraw X amount of cash from the ATM. 
//What is the minimum number of withdrawals Sarah would need to accumulate X amount of cash. If it is not possible for Sarah to withdraw X amount, return -1. 
public class Minimum_withdrwals {

	public static void main(String[] args) {
		
	}

}
