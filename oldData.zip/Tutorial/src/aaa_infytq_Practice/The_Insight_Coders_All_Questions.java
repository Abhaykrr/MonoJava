package aaa_infytq_Practice;

import java.util.*;
// Longest Substring in oN
// Great Sum
// pronic no nn+1 done
public class The_Insight_Coders_All_Questions {

//	public static void main(String[] args) {
//		Scanner x=new Scanner(System.in);
//		String s=x.next();
//		String output="";
//		
//		
//		//reverse String after removing duplicates
//		for(String c :s.split(""))
//		{
//			if(output.contains(c)==false)
//				output=c+output;
//		}
//		int a=10;
//		output+=a;
//		System.out.println(output);
//	}
	
	
	////////////////OTP Generator        ////////////////////
	
//	public static void main(String[] args) {
//		Scanner x=new Scanner(System.in);
//		String s=x.nextLine();
//		String output="";
//		int index=0;
//		for(String c:s.split(""))
//		{
//			 if(index%2!=0) {
//				 output+=(int)(Math.pow(Integer.parseInt(c), 2));
//			 }
//			 if(output.length()>=4)
//				 break;
//			 index++;
//		}
//		
//		System.out.println(output.substring(0,4));
//	
//	}
	
	
	///////////////////////Largest Even Number ////////////////////
	
	
//	public static void main(String[] args) {
//		Scanner x=new Scanner(System.in);
//		String s=x.nextLine();
//		ArrayList<Integer> l=new ArrayList<>();
//		String output="";
//		
//	for(int i=0;i<s.length();i++) {
//		int a=s.charAt(i);
//		if(a>=48&&a<=57) {
//			if(!l.contains(a-48))
//			l.add(a-48);
//		}
//	}
//	Collections.sort(l,Collections.reverseOrder());
//	
//	int pos=0;
//	for(int i=l.size()-1;i>=0;i--) {
//		if(l.get(i)%2==0) {
//			pos=1;
//			int small=l.get(i);
//			l.remove(i);
//			l.add(small);
//			break;
//		}
//	}
//	
//	if(pos==0) {
//		System.out.println(-1);
//	}else {
//		System.out.println(l);
//	}
//	
//	}

	////////////  Balanced Paranthesis ////////////////
	
//	public static void main(String[] args) {
//		Scanner x=new Scanner(System.in);
//		String s=x.nextLine();
//		
//		String arr[]=s.split(",");
//		
//		Stack<String> st=new Stack<>();
//		Stack<Integer> tt=new Stack<>();
//		
//		
//		for(int i=0;i<arr.length;i++) {
//			if(st.size()==0) {
//				st.push(arr[i]);
//				tt.push(i);
//			}
//			else {
//				String a=st.peek();
//				String b=arr[i];
//				
//				System.out.println(a+" "+b);
//				if(a.equals("[") && b.equals("]")) {
//					st.pop(); tt.pop();
//				}
//				else if(a.equals("(") && b.equals(")")) {
//					st.pop(); tt.pop();
//				}
//				else if(a.equals("{") && b.equals("}")) {
//					st.pop(); tt.pop();
//				}
//				
//				else {
//					st.push(arr[i]);
//					tt.push(i);
//				}
//				
//			}
//		}
//		System.out.println(st);
//		
//		if(st.size()==0)System.out.println("Balanced");
//		else System.out.println("Not Balanced");
//	}
	
	//////////////////////// Abhay:1234,Aman:23098 Madarchod Question/////////

//	public static void main(String[] args) {
//		Scanner x=new Scanner(System.in);
//		String s=x.nextLine();
//		String arr[]=s.split(",");
//		String output="";
//		
//		for(int i=0;i<arr.length;i++) {
//			String brr[]=arr[i].split(":");
//			
//			int len=brr[0].length();
//			int max=0;
//			for(String c:brr[1].split("")) {
//				int temp=Integer.parseInt(c);
//				
//				if(temp>max&&temp<=len) 
//					max=temp;
//				
//			}
//			
//			if(max==0) output+="X";
//			else output+=brr[0].charAt(max-1);
//		}
//		
//		System.out.println(output);
//		
//		
//	}  
	
	
	 ////////////////////Matrix sum//////////////////////////////
	
	
//	public static void main(String[] args) {
//		Scanner x=new Scanner(System.in);
//		String s=x.nextLine();
//		ArrayList<String> temp=new ArrayList<>();
//		String arr[]=s.split("");
//		
//		String ans[]=new String[26];
//		Arrays.fill(ans,"");
//		
//		for(int i=0;i<arr.length;i++) {
//			int a=arr[i].charAt(0);
//			
//			if(a>=65&&a<65+26) {
//				String b=ans[a-65];
//				b+=arr[i];
//				ans[a-65]=b;
//			}else {
//				String c=ans[a-97];
//				c+=arr[i];
//				ans[a-97]=c;
//			}
//		}
//		
//		for(int i=0;i<ans.length;i++) {
//			if(ans[i].equals("")!=true)
//				temp.add(ans[i]);
//		}
//		
//		System.out.println(temp);
//		String output="";
//		int i=0;
//		
//		while(temp.size()>0) {
//			if(i%2!=0) {
//			  output+=temp.get(temp.size()-1);
//			  temp.remove(temp.size()-1);
//			}else {
//				 output+=temp.get(0);
//				 temp.remove(0);
//			}
//			
//			i++;
//		}
//		
//		System.out.println(output);
//			
//		
//	}
	
	//////////////////////Matrix Sum of 2*2 /////////////////////////
//	public static void main(String[] args) {
//		Scanner x=new Scanner(System.in);
//		int m=x.nextInt();
//		int n=x.nextInt();
//		
//		int arr[][]=new int[m][n];
//		
//		for(int i=0;i<m;i++) {
//			for(int j=0;j<n;j++) {
//				arr[i][j]=x.nextInt();
//			}
//		}
//		
//		
//		for(int i=0;i<m;i++) {
//			for(int j=0;j<n;j++) {
//				if(i+1<m&&j+1<n) {
//					int a=arr[i][j];
//					int b=arr[i][j+1];
//					int c=arr[i+1][j];
//					int d=arr[i+1][j+1];
//					boolean ans=check(a,b,c,d);
//					if(ans==true) {
//						System.out.println(a+" "+b);
//						System.out.println(c+" "+d);
//					}
//				}
//			}
//		}
//		
//	}
//	
//	static boolean check(int a,int b,int c,int d) {
//		boolean ans=true;
//		
//		int arr[]= {a,b,c,d};
//		
//		for(int i=0;i<4;i++) {
//			int temp=arr[i];
//			int sum=0;
//			
//			while(temp>0) {
//				sum+=temp%10;
//				temp/=10;
//			}
//			
//			if(arr[i]%sum!=0) {
//				ans=false;
//				break;
//			}
//		}
//		
//		
//		return ans;
//	}
//	
	
	
	////// SpecialRevrsal keeping special char at same palace ///////////////////////
//	public static void main(String[] args) {
//		
//		Scanner x=new Scanner(System.in);
//		String s=x.nextLine();
//		
//		String arr[]=s.split("");
//		ArrayList<String> st=new ArrayList<>();
//		
//		
//		String output="";
//		
//		for(int i=0;i<arr.length;i++) {
//			if(arr[i].charAt(0)>='A'&arr[i].charAt(0)<='Z'
//					||arr[i].charAt(0)>='a'&arr[i].charAt(0)<='z' ) {
//			  st.add(arr[i]);
//			}
//		}
//		
//		for(int i=0;i<s.length();i++) {
//			if(arr[i].charAt(0)>='A'&arr[i].charAt(0)<='Z'
//					||arr[i].charAt(0)>='a'&arr[i].charAt(0)<='z' )
//			{
//				output+=st.get(st.size()-1);
//				st.remove(st.size()-1);
//			}else {
//				output+=arr[i];
//			}
//		}
//		
//		System.out.println(output);
//	}
	
	/////////////Longest Prefix Suffix ///////////////////
//	public static void main(String[] args) {
//		Scanner x=new Scanner(System.in);
//		String s=x.nextLine();
//		
//		int mid=s.length()/2;
//		int p1=mid;
//		int p2=mid;
//		
//		if(s.length()%2!=0) p2+=1;
//		while(p1>0) {
//			String a=s.substring(0,p1);
//			String b=s.substring(p2, s.length());
//			if(a.equals(b)) {
//				System.out.println(a+" " +a.length());
//			}
//			p1--;
//			p2++;
//			
//		}
//		
//		
//		
//	}	
	
	
	// Very Important ???????????????
//	public static void main(String[] args) {
//		Scanner x=new Scanner(System.in);
//		
//		int n=x.nextInt();
//		x.nextLine();
//		String s=x.nextLine();
//		
//		Map<Integer,Integer> st=new HashMap<>();
//		ArrayList<Integer> temp=new ArrayList<>();
// 		
//	    for(String c:s.split(" ")) {
//	    	int a=Integer.parseInt(c);
//	    	if(st.containsKey(a)) {
//	    		int b=st.get(a);
//	    		st.replace(a, b+1);
//	    	}else {
//	    		st.put(a, 1);
//	    	}
//	    }
//	    
//	    for(Map.Entry<Integer,Integer> entry : st.entrySet()) {
//	    	temp.add(entry.getValue());
//	    }
//	    Collections.sort(temp);
//	    System.out.println(temp);
//	    
//	    while(n>0&&temp.size()!=0) {
//	    	if(n>temp.get(0)) {
//	    		n-=temp.get(0);
//	    		temp.remove(0);
//	    	}else {
//	    		break;
//	    	}
//	    }
//		
//		System.out.println(temp.size());
//		
//	}
	
	public static void main(String[] args) {
		Scanner x=new Scanner(System.in);
		String a=x.nextLine();
		String b=x.nextLine();
		int suma=0;
		int sumb=0;
		
		ArrayList<Integer> arr=new ArrayList<>();
		ArrayList<Integer> brr=new ArrayList<>();
		ArrayList<Integer> ans=new ArrayList<>();
		
	 for(String c:a.split(" ")) arr.add(Integer.parseInt(c));
	 for(String c:b.split(" ")) brr.add(Integer.parseInt(c));
			 
		
	 for(int i=0;i<arr.size();i++) 
		 suma+=arr.get(i);
	 
	 for(int i=0;i<brr.size();i++) 
		 sumb+=brr.get(i);
	 
	 int eql=(suma+sumb)/2;
	 System.out.println(suma);
	 System.out.println(sumb);
	 
	 for(int i=0;i<arr.size();i++) {
		 if(brr.contains(sumb+arr.get(i)-eql)) {
			 System.out.println(arr.get(i)+" "+(sumb+arr.get(i)-eql));
		 }
	 }
	 
		
	}
		
}
