package aaa_infytq_Practice;

import java.util.*;
import java.util.List;

public class ListMCQ {

	public static void main(String[] args) {
		 List<String> list = new ArrayList<>(); 
	      list.add("I"); 
	      list.add("Love"); 
	      list.add("Java"); 
	      list.add("Language"); 
	      Iterator<String> iter = list.iterator(); 
	      while (iter.hasNext())
	         System.out.print (iter.next().toString() + " "); 
	      System.out.println();
	     
	      int a;
	      Bank bank=new Bank();
	      System.out.println(bank.bankName);
	   
	     }
	
	
	}

	
class Bank{
String bankName,area;
 public Bank(){
System.out.println("inside constructor");
}
}
