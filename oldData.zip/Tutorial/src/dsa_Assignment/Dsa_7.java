package dsa_Assignment;

import java.util.Scanner;

public class Dsa_7 {
// Write a program to add the elements of two matrices
	public static void main(String[] args) {
		// TODO Auto-generated method stub
   Scanner x=new Scanner(System.in);
   
   int arr[][]=new int[3][3];
   int arr1[][]=new int[3][3];
 
   
   System.out.println("Enter Elements Of Matrix 1");
   
   for(int i=0;i<3;i++) 
	   for(int j=0;j<3;j++) 
		   arr[i][j]=x.nextInt();
   
   System.out.println("Enter Elements Of Matrix 2");
   
   for(int i=0;i<3;i++) 
	   for(int j=0;j<3;j++) 
		   arr1[i][j]=x.nextInt();
   
   
   System.out.println("Sum of Matrix 1 And Matrix 2 is");
   
   for(int i=0;i<3;i++) {
	   for(int j=0;j<3;j++) {
		  System.out.print(arr1[i][j]+arr[i][j]+" ");}
       System.out.println();
   }
   
   
	   
	   
   }
   
	}


