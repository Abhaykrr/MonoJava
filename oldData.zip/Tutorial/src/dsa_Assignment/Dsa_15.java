package dsa_Assignment;

//Write a program to find the sum of all numbers present in nodes of linked list.

class MyLinkedList3 {
	
	 class Node{
	int data;
	Node next;
	Node prev;
	
	Node(int data){
		this.data=data;
		next=null;
		prev=null;
	}

	}       
	 Node head;
	
	
	  void add(int data) {
			Node toadd=new Node(data);
			if(head==null) {
				head=toadd;
				return;
			}
			
			else
			{
				Node n1=head;
				while(n1.next!=null) {
					n1=n1.next;
					
				}
				n1.next=toadd;
			}
		}
	void findSum() {
		Node p1=head;
		int sum=0;
		while(p1!=null) {
			sum+=p1.data;
			p1=p1.next;
		}
		System.out.println(sum);
	}
	
	
	
}
	

public class Dsa_15 {

	public static void main(String[] args) {
		// Write a program to find the sum of all numbers present in nodes of linked list.
MyLinkedList3 ll=new MyLinkedList3();
		
		ll.add(1);
		ll.add(2);
		ll.add(3);
		ll.add(4);
		ll.add(5);
		ll.add(6);
		ll.add(7);
		ll.add(8);
		
		ll.findSum();
	}

}
