package dsa_Assignment;

import java.util.Scanner;

public class Dsa_6 {
// Write a program to count the even numbers of the two-dimensional array.
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    
		Scanner x=new Scanner(System.in);
		System.out.println("Enter the Dimensions of the Array");
		int row =x.nextInt();
		int col=x.nextInt();
		int count=0;
		int arr[][]=new int[row][col];
		
		System.out.println("Enter the Elements in the Matrix with dimensions  "+row +" * "+col);
		
		for(int i=0;i<row;i++)
			for(int j=0;j<col;j++) {
				arr[i][j]=x.nextInt();
				if(arr[i][j]%2==0)
					count++;
			}
		
		System.out.println("There are "+ count+ " even Elements in the Multi dimensional Array  ");
		
	}

}
