package dsa_Assignment;

public class Dsa_11 {
// Write your own function to concatenate the two strings and then return the length of the resultant string.
	public static void main(String[] args) {
		
String a[]=new String[2];
String b[]=new String[2];

a[0]="Sir will ";
b[0]="Full Marks";
		
	}

}
