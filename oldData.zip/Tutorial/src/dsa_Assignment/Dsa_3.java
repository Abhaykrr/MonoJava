package dsa_Assignment;

public class Dsa_3 {
// Write a program to sort the elements in decreasing order using bubble sort.
	public static void main(String[] args) {
		
		int arr[]= {1, 2, 3, 4, 5};
		
	for(int i=0;i<arr.length;i++) {
		for(int j=0;j<arr.length-1;j++) {
			if(arr[j]<arr[j+1]) {
				int c=arr[j]*arr[j+1];
				arr[j]=c/arr[j];   arr[j+1]=c/arr[j+1];
			}
		}
	}
	
	for(Integer p1: arr)
		System.out.print(p1+" ");
	

	}

}
