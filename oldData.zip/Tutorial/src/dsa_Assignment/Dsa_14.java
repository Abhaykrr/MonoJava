package dsa_Assignment;
//Write a program to insert a new node after a node having second even number. 
//	Hint: search the second even number in the list and then after insert the new node.


class MyLinkedList2 {
	
	 class Node{
	int data;
	Node next;
	Node prev;
	
	Node(int data){
		this.data=data;
		next=null;
		prev=null;
	}

	}       
	 Node head;
	
	
	  void add(int data) {
			Node toadd=new Node(data);
			if(head==null) {
				head=toadd;
				return;
			}
			
			else
			{
				Node n1=head;
				while(n1.next!=null) {
					n1=n1.next;
					
				}
				n1.next=toadd;
			}
		}
	
	 void add_AfterSecond_Even(int data) {
		 Node p1=head;
		 Node toAdd=new Node(data);
		 Node temp=null;
		 int count=0;
		 while(p1!=null) {
			 if(p1.data%2==0)
				 count++;
			 
			 if(count==2) {
				 temp=p1.next;
				 p1.next=toAdd;
				 toAdd.next=temp;
			 }
			 
			 
			 p1=p1.next;
		 }
	 }
	 
	 void print() {
		 Node p1=head;
		 while(p1!=null) {
			 System.out.print(p1.data+" ");
			 p1=p1.next;
		 }
	 }
	
}
	

public class Dsa_14 {
// Write a program to insert a new node after a node having second even number. 
//	Hint: search the second even number in the list and then after insert the new node.
	public static void main(String[] args) {
		MyLinkedList2 ll=new MyLinkedList2();
		
		ll.add(1);
		ll.add(2);
		ll.add(3);
		ll.add(4);
		ll.add(5);
		ll.add(6);
		ll.add(7);
		ll.add(8);
		
		ll.add_AfterSecond_Even(10);
		ll.print();
		
	}

}
