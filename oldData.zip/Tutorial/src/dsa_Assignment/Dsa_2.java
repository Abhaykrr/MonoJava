package dsa_Assignment;

import java.util.Scanner;

public class Dsa_2 {
// Write a program to delete an element from the array with value of element.
	public static void main(String[] args) {
		Scanner x=new Scanner(System.in);
		System.out.println("Enter The Length of the Array");
		
		int length=x.nextInt();
		int arr[]=new int[length];
		
		System.out.println("Enter the Elements in the Array");
		
		for(int i=0;i<length;i++)
			arr[i]=x.nextInt();
		
		System.out.println("Enter the Element to be deleted");
		int toDel=x.nextInt();
		
		for(int i=0;i<length;i++) {
			if(arr[i]==toDel) {
				for(int j=i;j<length-1;j++) 
					arr[j]=arr[j+1];
				arr[length-1]=0;
				break;
			}
		}
		
		for(int i=0;i<length-1;i++) 
			System.out.print(arr[i] +" ");
		
		
		

	}

}
