package dsa_Assignment;
//Write a program to delete the last node from the linked list.
class MyLinkedList4 {
	
	 class Node{
	int data;
	Node next;
	Node prev;
	
	Node(int data){
		this.data=data;
		next=null;
		prev=null;
	}

	}       
	 Node head;
	
	
	  void add(int data) {
			Node toadd=new Node(data);
			if(head==null) {
				head=toadd;
				return;
			}
			
			else
			{
				Node n1=head;
				while(n1.next!=null) {
					n1=n1.next;
					
				}
				n1.next=toadd;
			}
		}
	  
	  void deleteLast() {
		  Node p1=head;
		  
		  while(p1.next.next!=null)
			  p1=p1.next;
		  p1.next=null;
		  
	  }
	  
	  void print() {
			 Node p1=head;
			 while(p1!=null) {
				 System.out.print(p1.data+" ");
				 p1=p1.next;
			 }
		 }
}



public class Dsa_16 {

	public static void main(String[] args) {
		// Write a program to delete the last node from the linked list.
MyLinkedList4 ll=new MyLinkedList4();
		
		ll.add(1);
		ll.add(2);
		ll.add(3);
		ll.add(4);
		ll.add(5);
		ll.add(6);
		ll.add(7);
		ll.add(8);
		
		ll.deleteLast();
		ll.print();
	}

}
