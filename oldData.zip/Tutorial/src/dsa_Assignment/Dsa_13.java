package dsa_Assignment;
//Write a program to search an item with given information in
// sorted linked list and find the search node position in terms of node position (i.e. at 1st node or 2nd node).


class MyLinkedList1 {
	
	 class Node{
	int data;
	Node next;
	Node prev;
	
	Node(int data){
		this.data=data;
		next=null;
		prev=null;
	}

	}       
	 Node head;
	
	
	  void add(int data) {
			Node toadd=new Node(data);
			if(head==null) {
				head=toadd;
				return;
			}
			
			else
			{
				Node n1=head;
				while(n1.next!=null) {
					n1=n1.next;
					
				}
				n1.next=toadd;
			}
		}
	  void find(int data) {
		  Node p1=head;
		  int Node_Position=0;
		  while(p1!=null) {
			  if(p1.data==data) {
				  Node_Position++;
				  System.out.println("Element found at Node position "+Node_Position);
				  break;
			  }
			  if(p1.next==null) 
				  System.out.println("Element Not found ");
			  
			  Node_Position++;
			  p1=p1.next;
		  }
		  
	  }
	
}
	

public class Dsa_13 {
// Write a program to search an item with given information in sorted linked list.
	public static void main(String[] args) {
	
		
		MyLinkedList1 ll=new MyLinkedList1();
		ll.add(0);
		ll.add(1);
		ll.add(2);
		ll.add(3);
		ll.add(4);;
		ll.add(3);
		ll.add(5);
		ll.add(6);
		ll.add(7);
		
		ll.find(5); 
		ll.find(10);

	}

}
