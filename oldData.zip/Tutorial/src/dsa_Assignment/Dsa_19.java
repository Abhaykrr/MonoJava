package dsa_Assignment;

import java.util.Scanner;

// Write a program to implement PUSH, POP and traverse operation using the menu options (choices).

class Stack {
	
	 class Node{
	int data;
	Node next;
	Node prev;
	
	Node(int data){
		this.data=data;
		next=null;
		prev=null;
	}

	}       
	 Node head;
	  void push(int data) {
			Node toadd=new Node(data);
			if(head==null) {
				head=toadd;
				System.out.println("Head added "+head.data);
				return;
			}
			
			else
			{
				Node n1=head;
				while(n1.next!=null) {
					n1=n1.next;
					
				}
				n1.next=toadd;
				System.out.println(toadd.data +" Added");
			}
		}
	  int pop() {
		  Node p1=head;
		  Node remove=null;
		  while(p1.next.next!=null) {
             p1=p1.next;
		  }
		  remove=p1.next;
		  System.out.println("Removed "+remove.data);
		  p1.next=null;
		  return remove.data;
	  }
	  void print() {
		  System.out.println("Elements are");
		  Node p1=head;
		  while(p1!=null) {
			  System.out.print(p1.data+ " ");
			  p1=p1.next;
		  }
		  System.out.println();
	  }
	
}
public class Dsa_19 {

	public static void main(String[] args) {
		// Write a program to implement PUSH, POP and traverse operation using the menu options (choices).
		// Stack implemented through Linked List
		Scanner x=new Scanner(System.in);
		Stack st=new Stack();
		
		while(true) {
			System.out.println("1 for push");
			System.out.println("2 for pop");
			System.out.println("3 for Traverse");
			System.out.println("5 for exit");
			int data=x.nextInt();
			if(data==1)
			{
				System.out.println("enter data");
				st.push(x.nextInt());
			}
			if(data==2) {
				st.pop();
				
			}
			if(data==3) {
				st.print();
			}
			if(data==4||data>4||data<1) {
				break;
			}
		}
		
	
		
		

	}

}
