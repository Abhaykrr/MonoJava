package dsa_Assignment;

//Write a program to insert a new node at the beginning of the two way list and then traverse into back direction.

class MyLinkedList5 {
	
	 class Node{
	int data;
	Node next;
	Node prev;
	
	Node(int data){
		this.data=data;
		next=null;
		prev=null;
	}

	}       
	 Node Head;
	
	
	 Node AddDouubly(int data) {
			Node p1=Head;
			Node toAdd=new Node(data);
			Node prev=null;
			
			if(Head==null) {
				Head=toAdd;
				return null;
			}
			else {
				while(p1.next!=null) {
					prev=p1;
					p1=p1.next;
				}
				p1.next=toAdd;
			    p1.prev=prev;
			}
			return Head;
		}
	 
	 
	 void Set(int value,int position) {
			Node p1=Head;
			Node toAdd=new Node(value);
		if(position>1) {
			for(int i=0;i<position-2;i++) 
				p1=p1.next;
			
			toAdd.next=p1.next;
			p1.next=toAdd;
		}
		else {
			Head=toAdd;
			toAdd.next=p1;
		}
		}
	 
	 void traverse_Back(Node Head) {
			Node p1=Head;
			if(p1.next==null) {
				System.out.print(p1.data+" ");
				return;
				}
			traverse_Back(p1.next);
			System.out.print(p1.data+" ");
			
		}
	 
	
}




public class Dsa_17 {

	public static void main(String[] args) {
		//Write a program to insert a new node at the beginning of the two way list and then traverse into back direction.
MyLinkedList5 ll=new MyLinkedList5();
		
		ll.AddDouubly(1);
		ll.AddDouubly(2);
		ll.AddDouubly(3);
		ll.AddDouubly(4);
		ll.AddDouubly(5);
		ll.AddDouubly(6);
		ll.AddDouubly(7);
		ll.AddDouubly(8);
		
		ll.Set(0, 1); // first data is value of the element and second data is the position
		ll.Set(10, 10);
		
		ll.traverse_Back(ll.Head);
	}

}
