package dsa_Assignment;

import java.util.Scanner;

public class Dsa_1 {
// Question No 2  Write a program to insert an element after the element 20 into the array
	public static void main(String[] args) {
		
		Scanner x=new Scanner(System.in);
		System.out.println("Enter The Length of the Array");
		
		int length=x.nextInt();
		int arr[]=new int[length+1];
		
		System.out.println("Enter the Elements in the Array");
		
		for(int i=0;i<length;i++)
			arr[i]=x.nextInt();
		
		System.out.println("Enter the Element that is to be inserted After the Element 20");
		int toAdd=x.nextInt();
		
		for(int i=0;i<length;i++) {   
			if(arr[i]==20) {
				for(int j=length;j>i;j--) 
					arr[j]=arr[j-1];
			
			arr[i+1]=toAdd;
			break;
			}
		}
		System.out.println("Array after Inserting Element 20");
		for(Integer p1:arr)
		System.out.print(p1+" ");

	}

}
