package dsa_Assignment;

public class Dsa_10 {
// Write your own function to search a pattern in given string.
	public static void main(String[] args) {
		

		String  main_String ="abcdabaabbcaaababaab";
		String  pattern       ="aab";
		
	}

}
