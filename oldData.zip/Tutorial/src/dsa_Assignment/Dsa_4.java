package dsa_Assignment;

public class Dsa_4 {
// Write a program to count the repeated number using linear search algorithm.
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      
		int arr[]= {1,3,4,5,1,2,4,5,8,9,10,2,3,1,1};
		
	}

}
