package cp_UA_Searching_and_Sorting;

public class Merge_Sort {

	public static void main(String[] args) {
		int arr[]= {10,7,6,2,9,1,9,24,7,13,3,3,8};
		mergeSort(arr,0,arr.length-1);
		
		
		 for(int i:arr)
			System.out.print(i+" ");
		

	}	
///////////////////////////////////////////////////////////
	public static void mergeSort(int[] arr,int l,int r) {
		if(r>l) {
			int mid=(l+r)/2;
			mergeSort(arr,l,mid);
			mergeSort(arr,mid+1,r);
			merge(arr,l,mid,r);
			
		}	
	}
	
public static void merge(int[] arr, int l, int mid, int r) {
	int i=l;
	int j=mid+1;
	int temp[]=new int[arr.length];
	int k=0;
	
	
	
	while(i<=mid&&j<=r) {
		if(arr[i]<=arr[j]) {
			temp[k]=arr[i];
			k++;
			i++;
			
		}else {
			temp[k]=arr[j];
			j++;
			k++;
		}
	}
	
	while(i<=mid) {
		temp[k]=arr[i];
		k++;
		i++;
	}
	while(j<=r) {
		temp[k]=arr[j];
		k++;
		j++;
	}
	
	for(int p=l,t=0;p<=r;p++,t++) 
		arr[p]=temp[t];
	
	
}

}
