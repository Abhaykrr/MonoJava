package cp_UA_Searching_and_Sorting;

public class Merge_sort_Question {

	public static void main(String[] args) {
	int arr[]= {4,9,-1,3,2};
	Mergesort(arr,0,arr.length-1);
	for(int i:arr)
		System.out.print(i+" ");
	}

	private static void Mergesort(int[] arr, int l, int r) {
		int count=0;
		if(r>l) {
	int mid=(l+r)/2;
	Mergesort(arr,l,mid);
	Mergesort(arr,mid+1,r);
	Merge(arr,l,mid,r);
	}
	
	}

	private static void Merge(int[] arr, int l, int mid, int r) {
	int i=l;
	int j=mid+1;
	int k=0;
	int swap=0;
	int temp[]=new int[arr.length];
	
	while(i<=mid&&j<=r) {
		if(arr[i]<=arr[j]) {
			temp[k]=arr[i];
			i++;
			k++;
		}else {
			swap+=mid-i+1;
			temp[k]=arr[j];
			j++;
			k++;
		}
	}
	while(i<=mid) {
		temp[k]=arr[i];
		k++;
		i++;
	}
	while(j<=r) {
		temp[k]=arr[j];
		k++;
		j++;
	}
	for(int p=l,q=0;p<=r;p++,q++) {
		arr[p]=temp[q];
	}
		
	//return swap;
	}

}
