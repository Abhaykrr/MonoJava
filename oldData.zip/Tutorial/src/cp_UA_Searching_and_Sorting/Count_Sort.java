package cp_UA_Searching_and_Sorting;

import java.util.Arrays;

public class Count_Sort {
	public static void main(String[] args) {
		int arr[]= {13,9,7,6,3,2,3,1,4,13,5,2};
		int dp[]=new int [101];
		Arrays.fill(dp, 0);
		
		
		for(int i=0;i<arr.length;i++) 
			++dp[arr[i]];
		
		for(int i=1;i<dp.length;i++) {
			if(dp[i]>0) {
				System.out.print(i+" ");
				--dp[i];
				i--;
			}
		}
		
	}
}
