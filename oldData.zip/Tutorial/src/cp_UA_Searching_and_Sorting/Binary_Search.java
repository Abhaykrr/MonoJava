package cp_UA_Searching_and_Sorting;

public class Binary_Search {

	public static void main(String[] args) {
		int arr[]= {1, 3 ,7 ,24 ,45,100};
		search(100,arr);

	}

	private static void search(int i,int[] arr) {
		int l=0;
		int r=arr.length;
		while(true) {
			if(r>l) {
				int mid=(l+r)/2;
				if(arr[mid]==i) {
					System.out.println("found");
					break;
				}
				
				if(i>arr[mid]) 
					l=mid+1;
			     else 
					r=mid-1;
				
		
			}
			else {
				
				System.out.println("not found");
				break;
			}
			
		}
		
	}

}
