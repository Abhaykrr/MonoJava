package cp_UA_Greedy;

import java.util.*;

public class Elephant_and_Music {
/*
	1 3
	1 5
	1 6
	2 3
	2 4*/
	
	
	public static void main(String[] args) {
	Scanner x=new Scanner(System.in);
	int test=x.nextInt();
	while(test--!=0) {
	HashMap<Integer,Integer> ll=new HashMap<>();
	int songs=x.nextInt();
ArrayList<Integer> arr=new ArrayList<>();
	long sum=0;
	for(int i=0;i<songs;i++) {  // input of n queries
		int b=x.nextInt();
		int l=x.nextInt();
		if(ll.containsKey(b)) {
			int val=ll.get(b);
			if(l<val) {
				ll.put(b,l);
				sum+=val;
				
			}
			else {
				sum+=l;
			}
		}
		else {
			ll.put(b, l);
		}
		
		
	}
	
	 for (Map.Entry<Integer,Integer> entry : ll.entrySet())
		arr.add(entry.getValue());
	 Collections.sort(arr);
	 int sum1=0;
	 int k=1;
	 for(int i:arr) {
	     sum1+=k*i;
	     k++;
	 }
	 sum=sum*(ll.size());
	 System.out.println(sum+sum1);
	}
	}

}
