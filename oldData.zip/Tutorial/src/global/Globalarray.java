package global;
import java.util.*;
public class Globalarray {

		public static void main(String[] args) {	
			
		 }	
    }
	
