package compeitivePrograming;

public class Replace_For_X {

	public static void main(String[] args) {
		int arr[]= {1,2,2,4,5,6};
		int i;
		for( i=0;i<arr.length;i++) {
			if(arr[i]>3) {
				break;
			}
		}
		
		System.out.println(i);

	}

}
