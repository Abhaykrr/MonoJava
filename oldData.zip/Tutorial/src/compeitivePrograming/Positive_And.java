package compeitivePrograming;

import java.util.*;

public class Positive_And {

	public static void main(String[] args) {
		int i=2;
		
		while(i<100000) {
			System.out.println(i);
			i*=2;
		}

	}

}
two.add(2);
two.add(4);
two.add(8);
two.add(16);
two.add(32);
two.add(64);
two.add(128);
two.add(256);
two.add(512);
two.add(1024);
two.add(2048);
two.add(4096);
two.add(8192);
two.add(16384);
two.add(32768);
two.add(65536);
