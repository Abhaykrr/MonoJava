package compeitivePrograming;

import java.util.Scanner;

public class Rainbow {

	public static void main(String[] args) {
		System.out.println(6%2);
		int i=0;
		i*i=16;
//		 Scanner x=new Scanner(System.in);
//		  int test=x.nextInt();
//		  while(test--!=0){
//		    int count=0;
//		    int length=x.nextInt();
//		    int toAdd=x.nextInt();
//		    if(toAdd<0)
//		    count++;
//		    int next=toAdd;
//		    for(int i=2;i<=length;i++){
//		      int a1=x.nextInt();
//		      if(a1%i==0&&a1/i==next){
//		        
//		      }else
//		      count++;
//		    }
//		    
//		    
//		    
//		    if(count==0)
//		    System.out.println("YES");
//		    else
//		    System.out.println("NO");
//		  }
//		
	}
}
