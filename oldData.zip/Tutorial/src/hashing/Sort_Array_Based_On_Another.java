package hashing;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class Sort_Array_Based_On_Another {

	public static void main(String[] args) {
		HashMap<Integer,Integer> ll=new LinkedHashMap<>();
		
		int fuel[]= {3,3,3,4,2,1};
		int cost[]= {2,1,2,5,3,1};
		
		int fuel1[]=new int[fuel.length];
		int cost1[]=new int[cost.length];
		
		for(int i=0;i<cost.length;i++) 
			ll.put(i,cost[i]);
		
		
		
		
		
	}

}
