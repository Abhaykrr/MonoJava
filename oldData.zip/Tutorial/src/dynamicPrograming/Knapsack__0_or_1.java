package dynamicPrograming;

import java.util.Arrays;

public class Knapsack__0_or_1 {

	public static void main(String[] args) {
	int net=10; 
	int weight[]= {1,2,3,4,7,8};
	int cost[]= {20,5,10,25,15,40};
	int dp[]=new int[net+1];
	Arrays.fill(dp, 0);
	dp[0]=0;
	int sum=0;
	
	for(int i=0;i<weight.length;i++) {
		sum+=cost[i];
		for(int j=weight[i];j<net+1;j++) {
			dp[j]=Math.max(dp[j], cost[i]+dp[j-weight[i]]);
		if(dp[j]>sum)
			dp[j]=dp[j-1];
	//	System.out.print(dp[j]+" ");
		}
	//	System.out.println();
		
	}
System.out.println(dp[net]);
	}

}
// explantion

/*
 *           0   1  2  3  4  5  6  7   8   9   10
 *       1  0   20
 *       3  0
         4  0
         6  0 
 
 */