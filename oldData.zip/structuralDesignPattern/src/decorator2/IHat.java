package decorator2;

public interface IHat {

	public String getName();
	public Double getPrice();
	public String getDescription();
}
