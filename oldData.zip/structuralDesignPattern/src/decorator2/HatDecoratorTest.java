package decorator2;

import java.util.Scanner;

public class HatDecoratorTest {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		IHat cap;
		HatDecorator hat;
		
		while(true) {
			System.out.print("Choose Standard Hat (1) or Premium Hat (2) : ");
			int choice  = scanner.nextInt();
			
			if(choice ==1 )
				cap = new StandardHat();
			else
				cap = new PremiumHat();
			
			
			System.out.println("New " +cap.getClass().getSimpleName()+" Created");
			System.out.println(cap);
			
			System.out.println("\nAny Modifications");
			System.out.print("Choose 1 for Golden Hat & 2 For Riboned Hat : ");
				choice = scanner.nextInt();
				
				if(choice ==1 )
					hat = new GoldenHat(cap);
				else
					hat = new RibonedHat(cap);
				
				System.out.println("Changed to " +hat.getClass().getSimpleName());
				System.out.println(hat);
				
				System.exit(0);	
			
			
		}
		
		}

}
