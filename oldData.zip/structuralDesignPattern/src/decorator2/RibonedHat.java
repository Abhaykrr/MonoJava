package decorator2;

public class RibonedHat extends HatDecorator {

	public RibonedHat(IHat hat) {
		super(hat);
	}
	
	public Double getPrice() {
		return 199 + super.getPrice();
	}

	@Override
	public String toString() {
		return "RibonedHat [(" + getPrice() + "," + getName() + ","
				+ getDescription()  + ")]";
	}
	
	

}
