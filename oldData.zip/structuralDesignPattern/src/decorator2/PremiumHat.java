package decorator2;

public class PremiumHat implements IHat{

	@Override
	public String getName() {
		return "Monkey Cap";
	}

	@Override
	public Double getPrice() {
		return 500.0;
	}

	@Override
	public String getDescription() {
		return "Sweat Free";
	}

	@Override
	public String toString() {
		return "Premium Hat [(" + getPrice() + "," + getName() + ","
				+ getDescription()  + ")]";
	}
	
	

}
