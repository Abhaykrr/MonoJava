package decorator2;

public class GoldenHat extends HatDecorator {

	public GoldenHat(IHat hat) {
		super(hat);
	}
	
	@Override
	public Double getPrice() {
		return 99 + super.getPrice();
	}

	@Override
	public String toString() {
		return "GoldenHat [(" + getPrice() + "," + getName() + ","
				+ getDescription()  + ")]";
	}
	
	

}
