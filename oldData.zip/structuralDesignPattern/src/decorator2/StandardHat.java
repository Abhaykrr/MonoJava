package decorator2;

public class StandardHat implements IHat {

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return "Urban Cap";
	}

	@Override
	public Double getPrice() {
		// TODO Auto-generated method stub
		return 200.0;
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return "Fancy & Comfortable";
	}

	@Override
	public String toString() {
		return "Standard Hat [(" + getPrice() + "," + getName() + ","
				+ getDescription()  + ")]";
	}
	
	

}
