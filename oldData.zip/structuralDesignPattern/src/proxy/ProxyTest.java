package proxy;

public class ProxyTest {
	
//	One of the advantages of Proxy pattern is security.
//	This pattern avoids duplication of objects which might be huge size and memory intensive. 
//	This in turn increases the performance of the application.
	
	
	public static void main(String[] args) {
        Image image1 = new ImageProxy("image1.jpg");
        Image image2 = new ImageProxy("image2.jpg");

        image1.display();
        image1.display();
        image2.display();
    }

}
