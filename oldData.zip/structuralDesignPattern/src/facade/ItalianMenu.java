package facade;

public class ItalianMenu implements Imenu{

	@Override
	public void displayMenu() {
		System.out.println("Spagiti");
		System.out.println("sejawan");
	}

}
