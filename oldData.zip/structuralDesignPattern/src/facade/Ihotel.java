package facade;

public interface Ihotel {

	Imenu getMenu();
}
