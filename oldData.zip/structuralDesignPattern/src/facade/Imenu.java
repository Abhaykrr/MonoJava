package facade;

public interface Imenu {
	
	void displayMenu();

}
