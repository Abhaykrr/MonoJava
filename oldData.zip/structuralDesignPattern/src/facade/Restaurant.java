package facade;

import java.util.Scanner;

public class Restaurant {

	public static void main(String[] args) {
		
		HotelReception hotelReception = new HotelReception();
		Scanner scanner = new Scanner(System.in);

		
		
		while(true) {
			  System.out.println("Menu:");
	            System.out.println("1. Get Indian Menu");
	            System.out.println("2. Get Italian Menu");
	            System.out.println("3. Exit");
	            System.out.print("Enter your choice: ");
	            
	           int choice = scanner.nextInt();
	            
	            switch (choice) {
	                case 1:
	                	hotelReception.getIndianMenu();
	                    break;
	                case 2:
	                	hotelReception.getItalianMenu();
	                    break;
	                 
	                case 3:
	                    System.out.println("Exit");
	                    break;
	                default:
	                    System.out.println("Invalid choice");
	                    break;
	            }
		}
		
	}

}
