package facade;

public class ItalianHotel implements Ihotel{
	
	@Override
	public Imenu getMenu() {
		return new ItalianMenu();
		
	}


}
