package facade;

public class IndianMenu implements Imenu{

	@Override
	public void displayMenu() {
		System.out.println("Rice");
		System.out.println("Dal");
	}

}
