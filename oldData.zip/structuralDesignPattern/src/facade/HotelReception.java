package facade;


public class HotelReception {
	
    public void getIndianMenu() {
        Ihotel indianHotel = new IndianHotel();
        Imenu menu = indianHotel.getMenu();
        menu.displayMenu();
    }
    
    public void getItalianMenu() {
        Ihotel italianHotel = new ItalianHotel();
        Imenu menu = italianHotel.getMenu();
        menu.displayMenu();
    }
    
    
}
