package facade;

public class IndianHotel implements Ihotel{

	@Override
	public Imenu getMenu() {
		return new IndianMenu();
	}

}
