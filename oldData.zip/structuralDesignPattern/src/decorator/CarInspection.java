package decorator;

public class CarInspection implements ICarService{

	public double getCost() {
		return 1000.00;
	}
}
