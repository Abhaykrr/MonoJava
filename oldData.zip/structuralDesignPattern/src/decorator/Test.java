package decorator;

public class Test {

	public static void main(String[] args) {
		ICarService car = new CarInspection();
		
		OilChange carOil =  new OilChange(car);
		
		WheelAlign carWheel = new WheelAlign(carOil);
		
		System.out.println(carWheel.getCost());
	}

}
