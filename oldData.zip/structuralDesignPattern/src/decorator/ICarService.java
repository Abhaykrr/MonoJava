package decorator;

public interface ICarService {

	public double getCost();
}
