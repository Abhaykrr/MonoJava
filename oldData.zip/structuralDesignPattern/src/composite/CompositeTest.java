package composite;

public class CompositeTest {
	
	//composite :made up of several parts or elements
	
	// Motivation
	//where we need to treat a group of objects in similar way as a single object

	public static void main(String[] args) {
		
		Component hd = new Leaf(7000,"HDD");
		Component mouse = new Leaf(5000,"Mouse");
		Component display = new Leaf(1000,"Display");
		Component monitor = new Leaf(2000,"Monitor");
		Component ram = new Leaf(3000,"Ram");
		Component cpu = new Leaf(4000,"Cpu");
		
		Composite ph = new Composite("Peripherals");
		Composite cabinet = new Composite("Cabinet");
		Composite mb = new Composite("MotherBoard");
		Composite computer = new Composite("Computer");
		
		ph.addComponent(mouse);
		ph.addComponent(monitor);
		
		mb.addComponent(cpu);
		mb.addComponent(ram);
		
		
		cabinet.addComponent(hd);
		cabinet.addComponent(mb);
		
		computer.addComponent(ph);
		computer.addComponent(cabinet);
		
		computer.getPrice();
		
		
		
	}

}
