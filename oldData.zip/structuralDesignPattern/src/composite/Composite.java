package composite;

import java.util.ArrayList;
import java.util.List;

public class Composite implements Component{
	
	private String name;
	private List<Component> components; 
	
	

	public Composite(String name) {
		this.name = name;
		this.components = new ArrayList<>();
	}
	
	public void addComponent(Component component) {
		components.add(component);
	}



	@Override
	public void getPrice() {
		System.out.println(name);
		
		components.stream().forEach((comp)->comp.getPrice() );
	}

}
