package adapter;

public interface IItems {
	
	public String getItemName();
	public Double getItemprice();

}
