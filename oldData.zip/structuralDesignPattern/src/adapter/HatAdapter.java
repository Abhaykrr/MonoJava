package adapter;

public class HatAdapter implements IItems {

	private Hat hat;
	
	

	public HatAdapter(Hat hat) {
		super();
		this.hat = hat;
	}

	@Override
	public String getItemName() {
		return this.hat.getShortName();
	}

	@Override
	public Double getItemprice() {
		return this.hat.getBasicPrice();
	}
	
	
}
