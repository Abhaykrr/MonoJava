package adapter;

import java.util.Arrays;

public class Test {

	public static void main(String[] args) {
		
		Biscuit biscut = new Biscuit("Parle G",10.0);
		HatAdapter hat =  new HatAdapter(new Hat("hat","summer hat",100.0,10.0));
		
	
		
		ShoppingCart sp = new ShoppingCart(Arrays.asList(hat,biscut));
		System.out.println(sp.getCartPrice());
		

	}

}
