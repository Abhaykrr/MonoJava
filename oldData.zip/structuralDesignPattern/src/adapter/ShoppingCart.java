package adapter;

import java.util.List;

public class ShoppingCart {
	
	private List<IItems> cartItems;

	public ShoppingCart(List<IItems> cartItems) {
		this.cartItems = cartItems;
	}
	
	public List<IItems> getCartItems() {
		return cartItems;
	}
	
	public Double getCartPrice() {
		
		return cartItems.stream()
		        .mapToDouble(item -> item.getItemprice())
		        .sum();
	}

}
