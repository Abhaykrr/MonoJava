package adapter;

public class Biscuit implements IItems {

	private String name;
	private Double mrp;
	
	
	
	public Biscuit(String name, Double mrp) {
		super();
		this.name = name;
		this.mrp = mrp;
	}
	@Override
	public String getItemName() {
		return name;
	}
	@Override
	public Double getItemprice() {
		return mrp;
	}
	@Override
	public String toString() {
		return "Biscuit [name=" + name + ", mrp=" + mrp + "]";
	}
	
	
	
	
}
