package s;

public class InvoiceManage {

	public static void main(String[] args) {
		
		Invoice invoice = new Invoice(1,"Abhay",30000.0);
		
		TaxCalculator.taxCalculator(invoice);
		InvoicePrinter.invoicePrinter(invoice);
	}

}
