package s;

public class TaxCalculator {
	
	static void taxCalculator(Invoice invoice){
		invoice.setTax((double)(8*invoice.getAmount())/100);
	}

}
