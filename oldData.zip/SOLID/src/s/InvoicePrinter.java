package s;

public class InvoicePrinter {
	
	 static void invoicePrinter(Invoice invoice){
		System.out.println("Invoice [invoiceId=" + invoice.getInvoiceId() + ", name=" + invoice.getName() + ", amount=" + invoice.getAmount() + ", tax=" + invoice.getTax() + "]"); 
		
	}

}
