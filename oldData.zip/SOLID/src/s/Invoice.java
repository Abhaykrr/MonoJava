package s;

public class Invoice {
	
	private int invoiceId;
	private String name;
	private Double amount;
	private Double tax;
	
	
	public Invoice(int invoiceId, String name, Double amount) {
		super();
		this.invoiceId = invoiceId;
		this.name = name;
		this.amount = amount;
	}


	public int getInvoiceId() {
		return invoiceId;
	}


	public void setInvoiceId(int invoiceId) {
		this.invoiceId = invoiceId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Double getAmount() {
		return amount;
	}


	public void setAmount(Double amount) {
		this.amount = amount;
	}


	public Double getTax() {
		return tax;
	}


	public void setTax(Double tax) {
		this.tax = tax;
	}
	

	
	

}
