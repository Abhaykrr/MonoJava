package ocp;

public class HoliInterest implements IFestivalInterest {

	@Override
	public double getInterestRates() {
		// TODO Auto-generated method stub
		return 7.5;
	}
}
