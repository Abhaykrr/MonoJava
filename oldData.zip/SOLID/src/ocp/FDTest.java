package ocp;

public class FDTest {

	public static void main(String[] args) {
		
		
		
//		FixedDeposit deposit1 = new FixedDeposit(1,"KK",5000.0,2,FestivalType.DIWALI);
//
//		FixedDeposit deposit2 = new FixedDeposit(2,"Ak",5000.0,2,FestivalType.HOLI);
//
//		FixedDeposit deposit3 = new FixedDeposit(3,"Sk",5000.0,2,FestivalType.NEWYEAR);
//		
//		Calculations.getInterestRates(deposit1);
//		System.out.println("Simple Interest Amount : " +Calculations.calculateSimpleInterest(deposit1));
//
//		Calculations.getInterestRates(deposit2);
//		System.out.println("Simple Interest Amount : " +Calculations.calculateSimpleInterest(deposit2));
//	
//		Calculations.getInterestRates(deposit3);
//		System.out.println("Simple Interest Amount : " +Calculations.calculateSimpleInterest(deposit3));
	
	}

}

