package ocp;

public enum FestivalType {
	NEWYEAR,DIWALI,HOLI,OTHERS
}
