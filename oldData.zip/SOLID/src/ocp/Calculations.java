package ocp;

public class Calculations {
	
//	static void getInterestRates(FixedDeposit fd) {
//		double interest = 6.5;
//		if(fd.getFestival()==FestivalType.DIWALI) interest = 8.5;
//		if(fd.getFestival()==FestivalType.HOLI) interest = 7.5;
//		if(fd.getFestival()==FestivalType.NEWYEAR) interest = 8;
//		fd.setInterest(interest);
//		
//	}
	
	public static double calculateSimpleInterest(FixedDeposit fd) {
		double interest = 0;
		
		interest = (double)(fd.getInterest()*fd.getPrincipal()*fd.getDuration())/100;
		
		return interest;
	}

}
