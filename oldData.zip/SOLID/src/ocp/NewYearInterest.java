package ocp;

public class NewYearInterest implements IFestivalInterest {

	@Override
	public double getInterestRates() {
		// TODO Auto-generated method stub
		return 8.5;
	}
}