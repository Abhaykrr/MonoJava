package ocp;

public interface IFestivalInterest {
	
	double getInterestRates();

}
