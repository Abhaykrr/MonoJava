package ocp;

public class OCP_Test {

	public static void main(String[] args) {
		
		
		FixedDeposit deposit1 = new FixedDeposit(1,"KK",5000.0,2, new DiwaliInterest());
		

		FixedDeposit deposit2 = new FixedDeposit(1,"AK",5000.0,2, new HoliInterest());
		

		FixedDeposit deposit3 = new FixedDeposit(1,"SK",5000.0,2, new NewYearInterest());
		
		
		System.out.println("Simple Interest Amount : " +Calculations.calculateSimpleInterest(deposit1));

		System.out.println("Simple Interest Amount : " +Calculations.calculateSimpleInterest(deposit2));

		System.out.println("Simple Interest Amount : " +Calculations.calculateSimpleInterest(deposit3));

	}

}
