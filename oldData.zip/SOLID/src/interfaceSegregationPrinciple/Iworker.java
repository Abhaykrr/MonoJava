package interfaceSegregationPrinciple;

public interface Iworker {
	
	void startWork();
	void stopWork();
	

}
