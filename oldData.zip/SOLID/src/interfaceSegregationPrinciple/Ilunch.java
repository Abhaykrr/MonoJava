package interfaceSegregationPrinciple;

public interface Ilunch {

	void eat();
	void drink();
}
