package interfaceSegregationPrinciple;

public class Labour implements Ilunch,Iworker {



	@Override
	public void eat() {

		System.out.println("Labour is eating");
		
	}

	@Override
	public void drink() {

		System.out.println("Labour is drinking");
		
	}

	@Override
	public void startWork() {
		System.out.println("Labour is working");
	}

	@Override
	public void stopWork() {
		System.out.println("Labour is stopping");
		
	}

}
