package dependencyInversionPrinciple;

public class TaxCalculator {
	
     private Ilogger ilogger;
     
	public TaxCalculator(Ilogger ilogger) {
		super();
		this.ilogger = ilogger;
	}


	public int calculateTax(int amount,int rate) {
		
		int tax = 0;
		try {
			tax = amount/rate;
			ilogger.log("Tax Calculated RS" +tax);
			
		}catch(Exception e) {
			ilogger.log("Cant Divide by Zero");
		}
		
		return tax;
	}
	
	

}
