package dependencyInversionPrinciple;

public class FileLogger implements Ilogger {

	@Override
	public void log(String msg) {
		
		System.out.println("File Logger :"+msg);
		
	}

}
