package dependencyInversionPrinciple;

public class DBLogger implements Ilogger{
	
	public void log(String msg) {
		System.out.println("DBLogger :"+msg	);
	}


}
