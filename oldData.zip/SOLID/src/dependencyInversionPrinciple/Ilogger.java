package dependencyInversionPrinciple;

public interface Ilogger {
	
	void log(String msg);

}
