package command;

public class TvRemote implements ICommand {
	
	boolean isTvOn = false;

	@Override
	public void on() {
		if(isTvOn==false) {
			System.out.println("Tv is Starting");
			isTvOn =true;
		}else {
			System.out.println("Tv is already started");
		}
			
	}

	@Override
	public void off() {
		
		if(isTvOn==true) {
			System.out.println("Tv is turning off");
			isTvOn =false;
		}else {
			System.out.println("Tv is already off");
		}
	}

	@Override
	public void increase() {
		if(isTvOn==true)
		System.out.println("Increasing volume");
		else {
			System.out.println("Tv is Off can't increase vol");
		}
	}

	@Override
	public void decrease() {
		if(isTvOn==true)
		System.out.println("Decreasing Volume");
		else {
			System.out.println("Tv is off can't decrease vol");
		}
	}

}
