package command;

public class Test {

	public static void main(String[] args) {
		
		ICommand tvRemote = new TvRemote();
		ICommand AcRemote = new AcRemote();
		
		Remote remote = new Remote(tvRemote);
		remote.increase();
		remote.off();
		remote.on();
		remote.on();
		remote.off();
		remote.increase();
		
		System.out.println();
		
		remote = new Remote(AcRemote);
		remote.increase();
		remote.off();
		remote.on();
		remote.on();
		remote.off();
		remote.increase();
		remote.decrease();
		
	}

}
