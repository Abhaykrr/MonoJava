package command;

public interface ICommand {

	public void on();
	public void off();
	public void increase();
	public void decrease();
}
