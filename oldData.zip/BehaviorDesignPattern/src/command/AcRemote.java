package command;

public class AcRemote implements ICommand{

	boolean isAcOn = false;
	
	@Override
	public void on() {
		if(isAcOn==false) {
			System.out.println("Ac is Starting");
			isAcOn =true;
		}else {
			System.out.println("Ac is already started");
		}
	}

	@Override
	public void off() {
		if(isAcOn==true) {
			System.out.println("Ac is turning off");
			isAcOn =false;
		}else {
			System.out.println("Ac is already off");
		}
	}

	@Override
	public void increase() {
		if(isAcOn==true)
		System.out.println("Increasing temperature");
		else {
			System.out.println("Ac is off cant do");
		}
	}

	@Override
	public void decrease() {
		if(isAcOn==true)
		System.out.println("Decreasing temperature");
		else {
			System.out.println("Ac is off cant do");
		}
	}

}
