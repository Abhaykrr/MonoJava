package command;

public class Remote {

	ICommand command;

	Remote(ICommand command){
		this.command = command;
	}
	
	public void on() {
		command.on();
	}

	public void off() {
		command.off();
	}

	public void increase() {
		command.increase();
	}

	public void decrease() {
		command.decrease();
	}

}
