package strategy;

public class AddOperation implements IOperation {

	@Override
	public int doOperatioon(int a, int b) {
		// TODO Auto-generated method stub
		return a+b;
	}

}
