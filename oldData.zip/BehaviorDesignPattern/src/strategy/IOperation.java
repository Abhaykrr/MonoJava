package strategy;

public interface IOperation {

	public int doOperatioon(int a,int b);
}
