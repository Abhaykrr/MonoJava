package strategy;

public class MultiplyOperation implements IOperation {

	@Override
	public int doOperatioon(int a, int b) {
		// TODO Auto-generated method stub
		return a*b;
	}

}
