package strategy;

public class StrategyTest {
	
	public static void main(String[] args) {
		
		OperationStrategy op = new OperationStrategy(new AddOperation());
		
		System.out.println(op.doOperation(10, 20));
		
		op = new OperationStrategy(new MultiplyOperation());
		System.out.println(op.doOperation(10, 20));
	}

}
