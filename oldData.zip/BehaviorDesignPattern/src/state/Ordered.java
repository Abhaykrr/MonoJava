package state;

public class Ordered implements PackageState {

	@Override
	public void previous(Package pack) {
		System.out.println("Package is already Source");
	}

	@Override
	public void next(Package pack) {
		pack.setState(new Delivered());
		
	}

	@Override
	public void status() {
		System.out.println("Package is Ordered");
		
	}
 
}
