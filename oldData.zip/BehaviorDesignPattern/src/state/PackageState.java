package state;

public interface PackageState {

	public void previous(Package pack);
	public void next(Package pack);
	public void status();
}
