package state;

public class Received implements PackageState {

	@Override
	public void previous(Package pack) {
		pack.setState(new Delivered());
	}

	@Override
	public void next(Package pack) {
		System.out.println("Package is alredy Received");
		
	}

	@Override
	public void status() {
		System.out.println("Package is Received");
		
	}
 
}
