package state;

public class Delivered implements PackageState {

	@Override
	public void previous(Package pack) {
		pack.setState(new Ordered());
	}

	@Override
	public void next(Package pack) {
		pack.setState(new Received());
		
	}

	@Override
	public void status() {
		System.out.println("Package is Delivered");
		
	}
 
}
