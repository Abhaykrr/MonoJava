package state;

public class Package {
	
	PackageState state = new Ordered();
	
	public PackageState getState() {
		return state;
	}
	
	public void setState(PackageState state) {
		this.state = state;
	}
	
	public void prevState() {
		state.previous(this);
	}
	
	public void nextState() {
		state.next(this);
	}
	
	public void printStatus() {
		state.status();
	}

}
