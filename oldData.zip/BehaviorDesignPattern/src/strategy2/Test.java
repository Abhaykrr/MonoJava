package strategy2;

public class Test {

	public static void main(String[] args) {
		
		Employee emp = new Employee(101,"Abhay",new Consultant());	

		System.out.println("Emp Name " +emp.getName()+", Emp Role: " +emp.getRole()+", Emp Description :" +emp.getDescription());
		
		emp.promote(new TechLead());
		
		System.out.println("Emp Name " +emp.getName()+", Emp Role: " +emp.getRole()+", Emp Description :" +emp.getDescription());
		
		emp.promote(new SeniorConsultant());
		
		System.out.println("Emp Name " +emp.getName()+", Emp Role: " +emp.getRole()+", Emp Description :" +emp.getDescription());
		 }
}