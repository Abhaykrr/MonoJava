package strategy2;

public interface IRole {

	public String description();
	public String responsibility();
}
