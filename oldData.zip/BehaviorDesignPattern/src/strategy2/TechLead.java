package strategy2;

public class TechLead implements IRole{

	@Override
	public String description() {
		// TODO Auto-generated method stub
		return "I do Research ";
	}

	@Override
	public String responsibility() {
		// TODO Auto-generated method stub
		return "Tech Lead";
	}

}
