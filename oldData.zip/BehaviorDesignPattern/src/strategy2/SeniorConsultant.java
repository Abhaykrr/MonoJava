package strategy2;

public class SeniorConsultant implements IRole{

	@Override
	public String description() {
		// TODO Auto-generated method stub
		return "I do Montoring of fellow consultants";
	}

	@Override
	public String responsibility() {
		// TODO Auto-generated method stub
		return "Senior Consultant";
	}

}
