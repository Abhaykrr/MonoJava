package observer;

public class SMSNotifier implements INotifier{

	@Override
	public void notify(Account acc) {
		
	}

}
