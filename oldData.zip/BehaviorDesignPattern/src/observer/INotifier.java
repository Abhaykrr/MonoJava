package observer;

public interface INotifier {
	
	public void notify(Account acc);

}
