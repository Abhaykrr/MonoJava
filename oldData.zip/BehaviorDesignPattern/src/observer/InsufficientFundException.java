package observer;

public class InsufficientFundException extends RuntimeException{
	
	private double amount;
	InsufficientFundException(double amount){
		this.amount = amount;
	}
	
	public String getMessage() {
		return "Net amount should not be less than 5000";
		
	}

}
