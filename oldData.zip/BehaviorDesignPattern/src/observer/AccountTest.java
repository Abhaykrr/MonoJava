package observer;

import java.util.Scanner;

public class AccountTest {

	public static void main(String[] args) {
		
		Scanner sacnner = new Scanner(System.in);
		INotifier notifier = null;
		
		Account account1 = new Account(1,"Abhay",5000);
		System.out.println("Account Created");
		System.out.println(account1);
		System.out.println();
		
		while(true) {
			System.out.println("Enter Choice ");
			System.out.println("1 >Set Email Notification");
			System.out.println("2 >Set WhatsApp Notification");
			System.out.println("3 >Set SMS Notification");
			System.out.println("4 >Add Amount");
			System.out.println("5 > Withdraw Amount");
			System.out.println("");
			
			int choice = sacnner.nextInt();
			
			if(choice  ==1 ) {
				notifier = new EmailNotifier();
			}
			if(choice  ==2 ) {
				notifier = new SMSNotifier();
			}
			
			if(choice  ==3 ) {
				notifier = new WhatsappNotifier();
			}
			
			if(choice == 4) {
				System.out.println("Enter Amount to Deposit");
				double amount = sacnner.nextDouble();
				account1.deposit(amount);
				
			}
			if(choice ==5 ) {
				System.out.println("Enter Amount to withdraw");
				double amount = sacnner.nextDouble();
				account1.withdraw(amount);
			}
			

			account1.registerNotifier(notifier);
			
			
		
		
		
		}

	}
}
