package observer;

import java.util.ArrayList;
import java.util.List;

public class Account {

	private int accountNumber;
	private String name;
	private double balance;
	private List<INotifier> notifiers;
	
	public Account(int accountNumber, String name, double balance) {
		super();
		this.accountNumber = accountNumber;
		this.name = name;
		this.balance = balance;
		notifiers = new ArrayList<>();
		
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public List<INotifier> getNotifiers() {
		return notifiers;
	}

	public void setNotifiers(List<INotifier> notifiers) {
		this.notifiers = notifiers;
	}
	
	public void deposit(double amount) {
		
		
		this.balance += amount;
		
		for(INotifier n :notifiers) {
			System.out.println("\n"+n.getClass().getSimpleName()+"Notification ");
			System.out.println("Amount added : " +amount);
			System.out.println("Net Amount : "+this.balance);
			System.out.println();
		}
		
		
		
		
	}
	
	public void withdraw(double amount) {
		try {
			if(balance-amount<5000) throw new InsufficientFundException(amount);
			
			this.balance -= amount;
			
			for(INotifier n :notifiers) {
				System.out.print("\n"+n.getClass().getSimpleName()+"Notification ");
				System.out.println("Amount Withdraw : " +amount);
				System.out.println("Net Amount : "+this.balance);
				System.out.println();
			}
		}catch(InsufficientFundException e) {
			System.out.println(e.getMessage());
		}
		
		
	}
	
	public void registerNotifier(INotifier iNotifier) {
		notifiers.add(iNotifier);
	}

	@Override
	public String toString() {
		
		String noti = "";
		
		for(INotifier n : notifiers) {
			noti +=n.getClass().getSimpleName()+",";
		}
		return "Account [accountNumber=" + accountNumber + ", name=" + name + ", balance=" + balance + ", notifiers="
				+ noti + "]";
	}
	
	
	
	
}
