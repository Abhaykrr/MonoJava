package observer;

public class WhatsappNotifier implements INotifier{

	@Override
	public void notify(Account acc) {
		// TODO Auto-generated method stub
		
	}

}
