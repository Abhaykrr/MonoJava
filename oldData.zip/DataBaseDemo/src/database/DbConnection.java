package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DbConnection {
	private static DbConnection dbConnection;
	private static Connection connection ;
	static Scanner scanner = new Scanner(System.in);
	private DbConnection() {

		
	    
	}
	
	void connect() {
		 String url = "jdbc:mysql://localhost:3306/Student";
	        String username = "root";
	        String password = "root";

	        try  {
	        	Class.forName("com.mysql.cj.jdbc.Driver");
	        	 connection =  DriverManager.getConnection(url, username, password);
	            
	        	
	        	System.out.println("Connected Successfully");
	      
	        	
	        	
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	}
	
	 void showFiles(String q) throws SQLException {
		Statement stm = connection.createStatement();
    	
    	ResultSet resultSet = stm.executeQuery(q);
    	
    	while(resultSet.next()) {
    		System.out.println(resultSet.getInt("roll_no")+" " +resultSet.getString("name"));
    	}
    	
    	resultSet.close();
    	stm.close();
    	connection.close();
	}
	
	 void addData() throws SQLException{
		 PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO STUDENTS VALUES (?, ?)");

		    System.out.println("Enter roll & name to Add");
		    int roll = scanner.nextInt();
		    String name = scanner.next();

		    preparedStatement.setInt(1, roll);
		    preparedStatement.setString(2, name);

		    preparedStatement.executeUpdate();
		    System.out.println("Data Added Successfully");
	 }
	 
	 void updateData() throws SQLException {
		    PreparedStatement preparedStatement = connection.prepareStatement("UPDATE STUDENTS SET name = ? WHERE roll_no = ?");

		    System.out.println("Enter roll & name to update");
		    int roll = scanner.nextInt();
		    String name = scanner.next();

		    preparedStatement.setString(1, name);
		    preparedStatement.setInt(2, roll);

		    preparedStatement.executeUpdate();
		        System.out.println("Data Updated Successfully");
		   
		}
	 
	 
	 void deleteData() throws SQLException {
		    PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM STUDENTS WHERE ROLL_NO = ?");

		    System.out.println("Enter roll to delete ");
		    int roll = scanner.nextInt();

		    preparedStatement.setInt(1, roll);	

		    preparedStatement.executeUpdate();
		        System.out.println("Deleted  Successfully");
		   
		}
		



	
	public static DbConnection getConnection() {
		
		 if (connection != null) {
			 System.out.println("Can Not create new instance");
			 return dbConnection;
         }	else {

    		 dbConnection = new  DbConnection();
    		 return dbConnection;
         }
	}
	
}
