package database;

import java.sql.SQLException;

public class Test {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		
		DbConnection db = DbConnection.getConnection();
		db.showFiles("select *  from students");
		System.out.println("\n\n");
		db.connect();
//		db.addData();
//		db.updateData();
		db.deleteData();
		db.showFiles("select *  from students");
		

		
	    }

}
