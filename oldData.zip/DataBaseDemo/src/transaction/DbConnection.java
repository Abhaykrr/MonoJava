package transaction;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DbConnection {
	private static DbConnection dbConnection;
	private static Connection connection ;
	static Scanner scanner = new Scanner(System.in);
	private DbConnection() {

		
	    
	}
	
	void connect() {
		 String url = "jdbc:mysql://localhost:3306/Student";
	        String username = "root";
	        String password = "root";

	        try  {
	        	Class.forName("com.mysql.cj.jdbc.Driver");
	        	 connection =  DriverManager.getConnection(url, username, password);
	            
	        	
	        	System.out.println("Connected Successfully");
	      
	        	
	        	
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	}
	

	void transaction() throws SQLException {
		
		try {
//			 connection.setAutoCommit(false); 
			String query1 = "INSERT INTO STUDENTS VALUES(16,'RAM')";
			String query2 = "INSERT INTO STUDENTS VALUES(15,'SAM')";
			
			PreparedStatement statement = connection.prepareStatement(query1);
			PreparedStatement statement2 = connection.prepareStatement(query2);
			
			
			int row1 = statement.executeUpdate();
			int row2 = statement2.executeUpdate();
			
//			if(row1>0 && row2>0) {
//				connection.commit();
//				System.out.println("Added Transaction successfully");
//			}else {
//				connection.rollback();
//				System.out.println("Transaction Failed");
//			}
			
			
			
		}catch(Exception e) {
			System.out.println("Transaction not completed. Error:"+e.getMessage());
		}
		
	}


	
	public static DbConnection getConnection() {
		
		 if (connection != null) {
			 System.out.println("Can Not create new instance");
			 return dbConnection;
         }	else {

    		 dbConnection = new  DbConnection();
    		 return dbConnection;
         }
	}
	
}
