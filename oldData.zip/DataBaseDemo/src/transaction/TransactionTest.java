package transaction;

import java.sql.SQLException;

public class TransactionTest {

//	Atomicity: All or nothing - Either the entire transaction is successful, or none of it is applied.
	
//	Consistency: Transactions maintain data integrity and adhere to predefined rules.
	
//	Isolation: Concurrent transactions do not interfere with each other's data modifications.
//	Locking
//	Concurrency ControL
//	Serializability
	
//	Durability: Committed changes are permanent and survive system failures.
	public static void main(String[] args) throws SQLException {
	
		DbConnection db = DbConnection.getConnection();
		db.connect();
		db.transaction();
	}

}
